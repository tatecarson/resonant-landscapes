import { createHotContext as __vite__createHotContext } from "/resonant-landscapes/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/HelpModal.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/resonant-landscapes/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/resonant-landscapes/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88dff54b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/resonant-landscapes/node_modules/.vite/deps/react.js?v=88dff54b"; const useRef = __vite__cjsImport2_react["useRef"]; const Fragment = __vite__cjsImport2_react["Fragment"];
import { Dialog, Transition } from "/resonant-landscapes/node_modules/.vite/deps/@headlessui_react.js?v=88dff54b";
function HelpModal({ isOpen, setIsOpen }) {
    _s();
    const cancelButtonRef = useRef(null);
    return /*#__PURE__*/ _jsxDEV(Transition.Root, {
        show: isOpen,
        as: Fragment,
        children: /*#__PURE__*/ _jsxDEV(Dialog, {
            as: "div",
            className: "relative z-10",
            initialFocus: cancelButtonRef,
            onClose: setIsOpen,
            children: [
                /*#__PURE__*/ _jsxDEV(Transition.Child, {
                    as: Fragment,
                    enter: "ease-out duration-300",
                    enterFrom: "opacity-0",
                    enterTo: "opacity-100",
                    leave: "ease-in duration-200",
                    leaveFrom: "opacity-100",
                    leaveTo: "opacity-0",
                    children: /*#__PURE__*/ _jsxDEV("div", {
                        className: "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"
                    }, void 0, false, {
                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
                        lineNumber: 20,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
                    lineNumber: 10,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ _jsxDEV("div", {
                    className: "fixed inset-0 w-screen overflow-y-auto",
                    children: /*#__PURE__*/ _jsxDEV("div", {
                        className: "flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0",
                        children: /*#__PURE__*/ _jsxDEV(Transition.Child, {
                            as: Fragment,
                            enter: "ease-out duration-300",
                            enterFrom: "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                            enterTo: "opacity-100 translate-y-0 sm:scale-100",
                            leave: "ease-in duration-200",
                            leaveFrom: "opacity-100 translate-y-0 sm:scale-100",
                            leaveTo: "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                            children: /*#__PURE__*/ _jsxDEV(Dialog.Panel, {
                                className: "relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4",
                                        children: /*#__PURE__*/ _jsxDEV("div", {
                                            className: "sm:flex sm:items-start",
                                            children: /*#__PURE__*/ _jsxDEV("div", {
                                                className: "mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left",
                                                children: [
                                                    /*#__PURE__*/ _jsxDEV(Dialog.Title, {
                                                        as: "h3",
                                                        className: "text-base font-semibold leading-6 text-gray-900",
                                                        children: "Troubleshooting"
                                                    }, void 0, false, {
                                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
                                                        lineNumber: 39,
                                                        columnNumber: 45
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("p", {
                                                        children: "For best results, turn WiFi off. If you don't hear sound, refresh the page or reopen the browser. Also, make sure geolocation is enabled in your phone/browser settings."
                                                    }, void 0, false, {
                                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
                                                        lineNumber: 43,
                                                        columnNumber: 45
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("br", {}, void 0, false, {
                                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
                                                        lineNumber: 44,
                                                        columnNumber: 45
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("p", {
                                                        children: "The app has been tested on iOS with Safari. It may not work with other devices or browsers."
                                                    }, void 0, false, {
                                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
                                                        lineNumber: 45,
                                                        columnNumber: 45
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("br", {}, void 0, false, {
                                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
                                                        lineNumber: 46,
                                                        columnNumber: 45
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("p", {
                                                        children: [
                                                            "Contact ",
                                                            /*#__PURE__*/ _jsxDEV("a", {
                                                                href: "mailto:tate.carson@dsu.edu",
                                                                className: "text-blue-600 visited:text-purple-600 underline",
                                                                children: "Tate Carson"
                                                            }, void 0, false, {
                                                                fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
                                                                lineNumber: 47,
                                                                columnNumber: 56
                                                            }, this),
                                                            " with questions and feedback."
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
                                                        lineNumber: 47,
                                                        columnNumber: 45
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
                                                lineNumber: 38,
                                                columnNumber: 41
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
                                            lineNumber: 37,
                                            columnNumber: 37
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
                                        lineNumber: 36,
                                        columnNumber: 33
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "bg-gray-50 px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6",
                                        children: /*#__PURE__*/ _jsxDEV("button", {
                                            type: "button",
                                            className: "mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 sm:mt-0 sm:w-auto",
                                            onClick: ()=>setIsOpen(false),
                                            ref: cancelButtonRef,
                                            children: "Continue"
                                        }, void 0, false, {
                                            fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
                                            lineNumber: 53,
                                            columnNumber: 37
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
                                        lineNumber: 51,
                                        columnNumber: 33
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
                                lineNumber: 35,
                                columnNumber: 29
                            }, this)
                        }, void 0, false, {
                            fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
                            lineNumber: 26,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
                        lineNumber: 25,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
                    lineNumber: 23,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
            lineNumber: 9,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx",
        lineNumber: 8,
        columnNumber: 9
    }, this);
}
_s(HelpModal, "KNmor9CpI5NkVXCuLb9g2pkalbc=");
_c = HelpModal;
export default HelpModal;
var _c;
$RefreshReg$(_c, "HelpModal");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/HelpModal.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkhlbHBNb2RhbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZVJlZiwgRnJhZ21lbnQgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IERpYWxvZywgVHJhbnNpdGlvbiB9IGZyb20gJ0BoZWFkbGVzc3VpL3JlYWN0J1xuXG5mdW5jdGlvbiBIZWxwTW9kYWwoeyBpc09wZW4sIHNldElzT3BlbiB9KSB7XG4gICAgY29uc3QgY2FuY2VsQnV0dG9uUmVmID0gdXNlUmVmKG51bGwpO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPFRyYW5zaXRpb24uUm9vdCBzaG93PXtpc09wZW59IGFzPXtGcmFnbWVudH0+XG4gICAgICAgICAgICA8RGlhbG9nIGFzPVwiZGl2XCIgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMFwiIGluaXRpYWxGb2N1cz17Y2FuY2VsQnV0dG9uUmVmfSBvbkNsb3NlPXtzZXRJc09wZW59PlxuICAgICAgICAgICAgICAgIDxUcmFuc2l0aW9uLkNoaWxkXG4gICAgICAgICAgICAgICAgICAgIGFzPXtGcmFnbWVudH1cbiAgICAgICAgICAgICAgICAgICAgZW50ZXI9XCJlYXNlLW91dCBkdXJhdGlvbi0zMDBcIlxuICAgICAgICAgICAgICAgICAgICBlbnRlckZyb209XCJvcGFjaXR5LTBcIlxuICAgICAgICAgICAgICAgICAgICBlbnRlclRvPVwib3BhY2l0eS0xMDBcIlxuICAgICAgICAgICAgICAgICAgICBsZWF2ZT1cImVhc2UtaW4gZHVyYXRpb24tMjAwXCJcbiAgICAgICAgICAgICAgICAgICAgbGVhdmVGcm9tPVwib3BhY2l0eS0xMDBcIlxuICAgICAgICAgICAgICAgICAgICBsZWF2ZVRvPVwib3BhY2l0eS0wXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHsvKiBCYWNrZ3JvdW5kICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctZ3JheS01MDAgYmctb3BhY2l0eS03NSB0cmFuc2l0aW9uLW9wYWNpdHlcIiAvPlxuICAgICAgICAgICAgICAgIDwvVHJhbnNpdGlvbi5DaGlsZD5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB3LXNjcmVlbiBvdmVyZmxvdy15LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAgey8qIENvbnRhaW5lciB0byBjZW50ZXIgdGhlIHBhbmVsICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtZnVsbCBpdGVtcy1lbmQganVzdGlmeS1jZW50ZXIgcC00IHRleHQtY2VudGVyIHNtOml0ZW1zLWNlbnRlciBzbTpwLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxUcmFuc2l0aW9uLkNoaWxkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXM9e0ZyYWdtZW50fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVudGVyPVwiZWFzZS1vdXQgZHVyYXRpb24tMzAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbnRlckZyb209XCJvcGFjaXR5LTAgdHJhbnNsYXRlLXktNCBzbTp0cmFuc2xhdGUteS0wIHNtOnNjYWxlLTk1XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbnRlclRvPVwib3BhY2l0eS0xMDAgdHJhbnNsYXRlLXktMCBzbTpzY2FsZS0xMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlYXZlPVwiZWFzZS1pbiBkdXJhdGlvbi0yMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlYXZlRnJvbT1cIm9wYWNpdHktMTAwIHRyYW5zbGF0ZS15LTAgc206c2NhbGUtMTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWF2ZVRvPVwib3BhY2l0eS0wIHRyYW5zbGF0ZS15LTQgc206dHJhbnNsYXRlLXktMCBzbTpzY2FsZS05NVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPERpYWxvZy5QYW5lbCBjbGFzc05hbWU9XCJyZWxhdGl2ZSB0cmFuc2Zvcm0gb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtbGcgYmctd2hpdGUgdGV4dC1sZWZ0IHNoYWRvdy14bCB0cmFuc2l0aW9uLWFsbCBzbTpteS04IHNtOnctZnVsbCBzbTptYXgtdy1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHB4LTQgcGItNCBwdC01IHNtOnAtNiBzbTpwYi00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmZsZXggc206aXRlbXMtc3RhcnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgdGV4dC1jZW50ZXIgc206bWwtNCBzbTptdC0wIHNtOnRleHQtbGVmdFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGlhbG9nLlRpdGxlIGFzPVwiaDNcIiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCBsZWFkaW5nLTYgdGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVHJvdWJsZXNob290aW5nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRGlhbG9nLlRpdGxlPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwPkZvciBiZXN0IHJlc3VsdHMsIHR1cm4gV2lGaSBvZmYuIElmIHlvdSBkb24ndCBoZWFyIHNvdW5kLCByZWZyZXNoIHRoZSBwYWdlIG9yIHJlb3BlbiB0aGUgYnJvd3Nlci4gQWxzbywgbWFrZSBzdXJlIGdlb2xvY2F0aW9uIGlzIGVuYWJsZWQgaW4geW91ciBwaG9uZS9icm93c2VyIHNldHRpbmdzLjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwPlRoZSBhcHAgaGFzIGJlZW4gdGVzdGVkIG9uIGlPUyB3aXRoIFNhZmFyaS4gSXQgbWF5IG5vdCB3b3JrIHdpdGggb3RoZXIgZGV2aWNlcyBvciBicm93c2Vycy48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiciAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cD5Db250YWN0IDxhIGhyZWY9J21haWx0bzp0YXRlLmNhcnNvbkBkc3UuZWR1JyBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIHZpc2l0ZWQ6dGV4dC1wdXJwbGUtNjAwIHVuZGVybGluZVwiPlRhdGUgQ2Fyc29uPC9hPiB3aXRoIHF1ZXN0aW9ucyBhbmQgZmVlZGJhY2suPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcHgtNCBweS0zIHNtOmZsZXggc206ZmxleC1yb3ctcmV2ZXJzZSBzbTpweC02XCI+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0zIGlubGluZS1mbGV4IHctZnVsbCBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLW1kIGJnLXdoaXRlIHB4LTMgcHktMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCBzaGFkb3ctc20gcmluZy0xIHJpbmctaW5zZXQgcmluZy1ncmF5LTMwMCBob3ZlcjpiZy1ncmF5LTUwIHNtOm10LTAgc206dy1hdXRvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc09wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlZj17Y2FuY2VsQnV0dG9uUmVmfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENvbnRpbnVlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9EaWFsb2cuUGFuZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L1RyYW5zaXRpb24uQ2hpbGQ+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9EaWFsb2c+XG4gICAgICAgIDwvVHJhbnNpdGlvbi5Sb290PlxuICAgIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgSGVscE1vZGFsOyAiXSwibmFtZXMiOlsidXNlUmVmIiwiRnJhZ21lbnQiLCJEaWFsb2ciLCJUcmFuc2l0aW9uIiwiSGVscE1vZGFsIiwiaXNPcGVuIiwic2V0SXNPcGVuIiwiY2FuY2VsQnV0dG9uUmVmIiwiUm9vdCIsInNob3ciLCJhcyIsImNsYXNzTmFtZSIsImluaXRpYWxGb2N1cyIsIm9uQ2xvc2UiLCJDaGlsZCIsImVudGVyIiwiZW50ZXJGcm9tIiwiZW50ZXJUbyIsImxlYXZlIiwibGVhdmVGcm9tIiwibGVhdmVUbyIsImRpdiIsIlBhbmVsIiwiVGl0bGUiLCJwIiwiYnIiLCJhIiwiaHJlZiIsImJ1dHRvbiIsInR5cGUiLCJvbkNsaWNrIiwicmVmIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUEsU0FBbUJBLE1BQU0sRUFBRUMsUUFBUSxRQUFRLFFBQU87QUFDbEQsU0FBU0MsTUFBTSxFQUFFQyxVQUFVLFFBQVEsb0JBQW1CO0FBRXRELFNBQVNDLFVBQVUsRUFBRUMsTUFBTSxFQUFFQyxTQUFTLEVBQUU7O0lBQ3BDLE1BQU1DLGtCQUFrQlAsT0FBTztJQUUvQixxQkFDSSxRQUFDRyxXQUFXSyxJQUFJO1FBQUNDLE1BQU1KO1FBQVFLLElBQUlUO2tCQUMvQixjQUFBLFFBQUNDO1lBQU9RLElBQUc7WUFBTUMsV0FBVTtZQUFnQkMsY0FBY0w7WUFBaUJNLFNBQVNQOzs4QkFDL0UsUUFBQ0gsV0FBV1csS0FBSztvQkFDYkosSUFBSVQ7b0JBQ0pjLE9BQU07b0JBQ05DLFdBQVU7b0JBQ1ZDLFNBQVE7b0JBQ1JDLE9BQU07b0JBQ05DLFdBQVU7b0JBQ1ZDLFNBQVE7OEJBR1IsY0FBQSxRQUFDQzt3QkFBSVYsV0FBVTs7Ozs7Ozs7Ozs7OEJBR25CLFFBQUNVO29CQUFJVixXQUFVOzhCQUVYLGNBQUEsUUFBQ1U7d0JBQUlWLFdBQVU7a0NBQ1gsY0FBQSxRQUFDUixXQUFXVyxLQUFLOzRCQUNiSixJQUFJVDs0QkFDSmMsT0FBTTs0QkFDTkMsV0FBVTs0QkFDVkMsU0FBUTs0QkFDUkMsT0FBTTs0QkFDTkMsV0FBVTs0QkFDVkMsU0FBUTtzQ0FFUixjQUFBLFFBQUNsQixPQUFPb0IsS0FBSztnQ0FBQ1gsV0FBVTs7a0RBQ3BCLFFBQUNVO3dDQUFJVixXQUFVO2tEQUNYLGNBQUEsUUFBQ1U7NENBQUlWLFdBQVU7c0RBQ1gsY0FBQSxRQUFDVTtnREFBSVYsV0FBVTs7a0VBQ1gsUUFBQ1QsT0FBT3FCLEtBQUs7d0RBQUNiLElBQUc7d0RBQUtDLFdBQVU7a0VBQWtEOzs7Ozs7a0VBSWxGLFFBQUNhO2tFQUFFOzs7Ozs7a0VBQ0gsUUFBQ0M7Ozs7O2tFQUNELFFBQUNEO2tFQUFFOzs7Ozs7a0VBQ0gsUUFBQ0M7Ozs7O2tFQUNELFFBQUNEOzs0REFBRTswRUFBUSxRQUFDRTtnRUFBRUMsTUFBSztnRUFBNkJoQixXQUFVOzBFQUFrRDs7Ozs7OzREQUFlOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztrREFJdkksUUFBQ1U7d0NBQUlWLFdBQVU7a0RBRVgsY0FBQSxRQUFDaUI7NENBQ0dDLE1BQUs7NENBQ0xsQixXQUFVOzRDQUNWbUIsU0FBUyxJQUFNeEIsVUFBVTs0Q0FDekJ5QixLQUFLeEI7c0RBQ1I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFXckM7R0FqRVNIO0tBQUFBO0FBbUVULGVBQWVBLFVBQVUifQ==