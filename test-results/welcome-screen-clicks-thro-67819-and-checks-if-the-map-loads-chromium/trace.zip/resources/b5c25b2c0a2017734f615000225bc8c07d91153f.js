import { createHotContext as __vite__createHotContext } from "/resonant-landscapes/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/WelcomeModal.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/resonant-landscapes/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/resonant-landscapes/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88dff54b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/resonant-landscapes/node_modules/.vite/deps/react.js?v=88dff54b"; const useRef = __vite__cjsImport2_react["useRef"]; const Fragment = __vite__cjsImport2_react["Fragment"];
import { Dialog, Transition } from "/resonant-landscapes/node_modules/.vite/deps/@headlessui_react.js?v=88dff54b";
function WelcomeModal({ isOpen, setIsOpen }) {
    _s();
    const cancelButtonRef = useRef(null);
    return /*#__PURE__*/ _jsxDEV(Transition.Root, {
        show: isOpen,
        as: Fragment,
        children: /*#__PURE__*/ _jsxDEV(Dialog, {
            as: "div",
            className: "relative z-10",
            initialFocus: cancelButtonRef,
            onClose: setIsOpen,
            children: [
                /*#__PURE__*/ _jsxDEV(Transition.Child, {
                    as: Fragment,
                    enter: "ease-out duration-300",
                    enterFrom: "opacity-0",
                    enterTo: "opacity-100",
                    leave: "ease-in duration-200",
                    leaveFrom: "opacity-100",
                    leaveTo: "opacity-0",
                    children: /*#__PURE__*/ _jsxDEV("div", {
                        className: "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"
                    }, void 0, false, {
                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                        lineNumber: 20,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                    lineNumber: 10,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ _jsxDEV("div", {
                    className: "fixed inset-0 w-screen overflow-y-auto",
                    children: /*#__PURE__*/ _jsxDEV("div", {
                        className: "flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0",
                        children: /*#__PURE__*/ _jsxDEV(Transition.Child, {
                            as: Fragment,
                            enter: "ease-out duration-300",
                            enterFrom: "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                            enterTo: "opacity-100 translate-y-0 sm:scale-100",
                            leave: "ease-in duration-200",
                            leaveFrom: "opacity-100 translate-y-0 sm:scale-100",
                            leaveTo: "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                            children: /*#__PURE__*/ _jsxDEV(Dialog.Panel, {
                                className: "relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4",
                                        children: /*#__PURE__*/ _jsxDEV("div", {
                                            className: "sm:flex sm:items-start",
                                            children: /*#__PURE__*/ _jsxDEV("div", {
                                                className: "mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left",
                                                children: [
                                                    /*#__PURE__*/ _jsxDEV(Dialog.Title, {
                                                        as: "h1",
                                                        className: "text-base font-semibold leading-6 text-gray-900",
                                                        children: "Welcome to Resonant Landscapes"
                                                    }, void 0, false, {
                                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                                                        lineNumber: 39,
                                                        columnNumber: 45
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("p", {
                                                        children: "Walk around DSU's campus to hear sounds recorded in each of South Dakota's 13 State Parks."
                                                    }, void 0, false, {
                                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                                                        lineNumber: 43,
                                                        columnNumber: 45
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("br", {}, void 0, false, {
                                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                                                        lineNumber: 44,
                                                        columnNumber: 45
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("p", {
                                                        children: " As you approach a park, a menu will pop up that will allow you to play a recording. As you walk closer to the center icon, the recording volume will increase."
                                                    }, void 0, false, {
                                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                                                        lineNumber: 45,
                                                        columnNumber: 45
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("br", {}, void 0, false, {
                                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                                                        lineNumber: 46,
                                                        columnNumber: 45
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("p", {
                                                        children: "When you're in the center of the listening spot, you'll have the option to reorient your listening direction by turning with your phone. This will allow you to hear the recording in 360 degrees."
                                                    }, void 0, false, {
                                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                                                        lineNumber: 47,
                                                        columnNumber: 45
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("br", {}, void 0, false, {
                                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                                                        lineNumber: 48,
                                                        columnNumber: 45
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("p", {
                                                        children: "To hear a different recording from the same park, close the menu and another recording will load. To stop a recording, click the stop button or walk away from the park."
                                                    }, void 0, false, {
                                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                                                        lineNumber: 49,
                                                        columnNumber: 45
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("br", {}, void 0, false, {
                                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                                                        lineNumber: 50,
                                                        columnNumber: 45
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                                                lineNumber: 38,
                                                columnNumber: 41
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                                            lineNumber: 37,
                                            columnNumber: 37
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                                        lineNumber: 36,
                                        columnNumber: 33
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "bg-gray-50 px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6",
                                        children: /*#__PURE__*/ _jsxDEV("button", {
                                            type: "button",
                                            id: "welcome-button",
                                            className: "mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 sm:mt-0 sm:w-auto",
                                            onClick: ()=>setIsOpen(false),
                                            ref: cancelButtonRef,
                                            children: "Continue"
                                        }, void 0, false, {
                                            fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                                            lineNumber: 55,
                                            columnNumber: 37
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                                        lineNumber: 54,
                                        columnNumber: 33
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                                lineNumber: 35,
                                columnNumber: 29
                            }, this)
                        }, void 0, false, {
                            fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                            lineNumber: 26,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                        lineNumber: 25,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
                    lineNumber: 23,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
            lineNumber: 9,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx",
        lineNumber: 8,
        columnNumber: 9
    }, this);
}
_s(WelcomeModal, "KNmor9CpI5NkVXCuLb9g2pkalbc=");
_c = WelcomeModal;
export default WelcomeModal;
var _c;
$RefreshReg$(_c, "WelcomeModal");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/WelcomeModal.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIldlbGNvbWVNb2RhbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZVJlZiwgRnJhZ21lbnQgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBEaWFsb2csIFRyYW5zaXRpb24gfSBmcm9tICdAaGVhZGxlc3N1aS9yZWFjdCc7XG5cbmZ1bmN0aW9uIFdlbGNvbWVNb2RhbCh7IGlzT3Blbiwgc2V0SXNPcGVuIH0pIHtcbiAgICBjb25zdCBjYW5jZWxCdXR0b25SZWYgPSB1c2VSZWYobnVsbCk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8VHJhbnNpdGlvbi5Sb290IHNob3c9e2lzT3Blbn0gYXM9e0ZyYWdtZW50fT5cbiAgICAgICAgICAgIDxEaWFsb2cgYXM9XCJkaXZcIiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwXCIgaW5pdGlhbEZvY3VzPXtjYW5jZWxCdXR0b25SZWZ9IG9uQ2xvc2U9e3NldElzT3Blbn0+XG4gICAgICAgICAgICAgICAgPFRyYW5zaXRpb24uQ2hpbGRcbiAgICAgICAgICAgICAgICAgICAgYXM9e0ZyYWdtZW50fVxuICAgICAgICAgICAgICAgICAgICBlbnRlcj1cImVhc2Utb3V0IGR1cmF0aW9uLTMwMFwiXG4gICAgICAgICAgICAgICAgICAgIGVudGVyRnJvbT1cIm9wYWNpdHktMFwiXG4gICAgICAgICAgICAgICAgICAgIGVudGVyVG89XCJvcGFjaXR5LTEwMFwiXG4gICAgICAgICAgICAgICAgICAgIGxlYXZlPVwiZWFzZS1pbiBkdXJhdGlvbi0yMDBcIlxuICAgICAgICAgICAgICAgICAgICBsZWF2ZUZyb209XCJvcGFjaXR5LTEwMFwiXG4gICAgICAgICAgICAgICAgICAgIGxlYXZlVG89XCJvcGFjaXR5LTBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgey8qIEJhY2tncm91bmQgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ncmF5LTUwMCBiZy1vcGFjaXR5LTc1IHRyYW5zaXRpb24tb3BhY2l0eVwiIC8+XG4gICAgICAgICAgICAgICAgPC9UcmFuc2l0aW9uLkNoaWxkPlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHctc2NyZWVuIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICB7LyogQ29udGFpbmVyIHRvIGNlbnRlciB0aGUgcGFuZWwgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC1mdWxsIGl0ZW1zLWVuZCBqdXN0aWZ5LWNlbnRlciBwLTQgdGV4dC1jZW50ZXIgc206aXRlbXMtY2VudGVyIHNtOnAtMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFRyYW5zaXRpb24uQ2hpbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcz17RnJhZ21lbnR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZW50ZXI9XCJlYXNlLW91dCBkdXJhdGlvbi0zMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVudGVyRnJvbT1cIm9wYWNpdHktMCB0cmFuc2xhdGUteS00IHNtOnRyYW5zbGF0ZS15LTAgc206c2NhbGUtOTVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVudGVyVG89XCJvcGFjaXR5LTEwMCB0cmFuc2xhdGUteS0wIHNtOnNjYWxlLTEwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGVhdmU9XCJlYXNlLWluIGR1cmF0aW9uLTIwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGVhdmVGcm9tPVwib3BhY2l0eS0xMDAgdHJhbnNsYXRlLXktMCBzbTpzY2FsZS0xMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlYXZlVG89XCJvcGFjaXR5LTAgdHJhbnNsYXRlLXktNCBzbTp0cmFuc2xhdGUteS0wIHNtOnNjYWxlLTk1XCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGlhbG9nLlBhbmVsIGNsYXNzTmFtZT1cInJlbGF0aXZlIHRyYW5zZm9ybSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1sZyBiZy13aGl0ZSB0ZXh0LWxlZnQgc2hhZG93LXhsIHRyYW5zaXRpb24tYWxsIHNtOm15LTggc206dy1mdWxsIHNtOm1heC13LWxnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcHgtNCBwYi00IHB0LTUgc206cC02IHNtOnBiLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206ZmxleCBzbTppdGVtcy1zdGFydFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LWNlbnRlciBzbTptbC00IHNtOm10LTAgc206dGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEaWFsb2cuVGl0bGUgYXM9XCJoMVwiIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIGxlYWRpbmctNiB0ZXh0LWdyYXktOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBXZWxjb21lIHRvIFJlc29uYW50IExhbmRzY2FwZXNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9EaWFsb2cuVGl0bGU+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHA+V2FsayBhcm91bmQgRFNVJ3MgY2FtcHVzIHRvIGhlYXIgc291bmRzIHJlY29yZGVkIGluIGVhY2ggb2YgU291dGggRGFrb3RhJ3MgMTMgU3RhdGUgUGFya3MuPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHA+IEFzIHlvdSBhcHByb2FjaCBhIHBhcmssIGEgbWVudSB3aWxsIHBvcCB1cCB0aGF0IHdpbGwgYWxsb3cgeW91IHRvIHBsYXkgYSByZWNvcmRpbmcuIEFzIHlvdSB3YWxrIGNsb3NlciB0byB0aGUgY2VudGVyIGljb24sIHRoZSByZWNvcmRpbmcgdm9sdW1lIHdpbGwgaW5jcmVhc2UuPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHA+V2hlbiB5b3UncmUgaW4gdGhlIGNlbnRlciBvZiB0aGUgbGlzdGVuaW5nIHNwb3QsIHlvdSdsbCBoYXZlIHRoZSBvcHRpb24gdG8gcmVvcmllbnQgeW91ciBsaXN0ZW5pbmcgZGlyZWN0aW9uIGJ5IHR1cm5pbmcgd2l0aCB5b3VyIHBob25lLiBUaGlzIHdpbGwgYWxsb3cgeW91IHRvIGhlYXIgdGhlIHJlY29yZGluZyBpbiAzNjAgZGVncmVlcy48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiciAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cD5UbyBoZWFyIGEgZGlmZmVyZW50IHJlY29yZGluZyBmcm9tIHRoZSBzYW1lIHBhcmssIGNsb3NlIHRoZSBtZW51IGFuZCBhbm90aGVyIHJlY29yZGluZyB3aWxsIGxvYWQuIFRvIHN0b3AgYSByZWNvcmRpbmcsIGNsaWNrIHRoZSBzdG9wIGJ1dHRvbiBvciB3YWxrIGF3YXkgZnJvbSB0aGUgcGFyay48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiciAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcHgtNCBweS0zIHNtOmZsZXggc206ZmxleC1yb3ctcmV2ZXJzZSBzbTpweC02XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJ3ZWxjb21lLWJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMyBpbmxpbmUtZmxleCB3LWZ1bGwganVzdGlmeS1jZW50ZXIgcm91bmRlZC1tZCBiZy13aGl0ZSBweC0zIHB5LTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgc2hhZG93LXNtIHJpbmctMSByaW5nLWluc2V0IHJpbmctZ3JheS0zMDAgaG92ZXI6YmctZ3JheS01MCBzbTptdC0wIHNtOnctYXV0b1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWY9e2NhbmNlbEJ1dHRvblJlZn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDb250aW51ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRGlhbG9nLlBhbmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9UcmFuc2l0aW9uLkNoaWxkPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvRGlhbG9nPlxuICAgICAgICA8L1RyYW5zaXRpb24uUm9vdD5cbiAgICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBXZWxjb21lTW9kYWw7Il0sIm5hbWVzIjpbInVzZVJlZiIsIkZyYWdtZW50IiwiRGlhbG9nIiwiVHJhbnNpdGlvbiIsIldlbGNvbWVNb2RhbCIsImlzT3BlbiIsInNldElzT3BlbiIsImNhbmNlbEJ1dHRvblJlZiIsIlJvb3QiLCJzaG93IiwiYXMiLCJjbGFzc05hbWUiLCJpbml0aWFsRm9jdXMiLCJvbkNsb3NlIiwiQ2hpbGQiLCJlbnRlciIsImVudGVyRnJvbSIsImVudGVyVG8iLCJsZWF2ZSIsImxlYXZlRnJvbSIsImxlYXZlVG8iLCJkaXYiLCJQYW5lbCIsIlRpdGxlIiwicCIsImJyIiwiYnV0dG9uIiwidHlwZSIsImlkIiwib25DbGljayIsInJlZiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBLFNBQW1CQSxNQUFNLEVBQUVDLFFBQVEsUUFBUSxRQUFRO0FBQ25ELFNBQVNDLE1BQU0sRUFBRUMsVUFBVSxRQUFRLG9CQUFvQjtBQUV2RCxTQUFTQyxhQUFhLEVBQUVDLE1BQU0sRUFBRUMsU0FBUyxFQUFFOztJQUN2QyxNQUFNQyxrQkFBa0JQLE9BQU87SUFFL0IscUJBQ0ksUUFBQ0csV0FBV0ssSUFBSTtRQUFDQyxNQUFNSjtRQUFRSyxJQUFJVDtrQkFDL0IsY0FBQSxRQUFDQztZQUFPUSxJQUFHO1lBQU1DLFdBQVU7WUFBZ0JDLGNBQWNMO1lBQWlCTSxTQUFTUDs7OEJBQy9FLFFBQUNILFdBQVdXLEtBQUs7b0JBQ2JKLElBQUlUO29CQUNKYyxPQUFNO29CQUNOQyxXQUFVO29CQUNWQyxTQUFRO29CQUNSQyxPQUFNO29CQUNOQyxXQUFVO29CQUNWQyxTQUFROzhCQUdSLGNBQUEsUUFBQ0M7d0JBQUlWLFdBQVU7Ozs7Ozs7Ozs7OzhCQUduQixRQUFDVTtvQkFBSVYsV0FBVTs4QkFFWCxjQUFBLFFBQUNVO3dCQUFJVixXQUFVO2tDQUNYLGNBQUEsUUFBQ1IsV0FBV1csS0FBSzs0QkFDYkosSUFBSVQ7NEJBQ0pjLE9BQU07NEJBQ05DLFdBQVU7NEJBQ1ZDLFNBQVE7NEJBQ1JDLE9BQU07NEJBQ05DLFdBQVU7NEJBQ1ZDLFNBQVE7c0NBRVIsY0FBQSxRQUFDbEIsT0FBT29CLEtBQUs7Z0NBQUNYLFdBQVU7O2tEQUNwQixRQUFDVTt3Q0FBSVYsV0FBVTtrREFDWCxjQUFBLFFBQUNVOzRDQUFJVixXQUFVO3NEQUNYLGNBQUEsUUFBQ1U7Z0RBQUlWLFdBQVU7O2tFQUNYLFFBQUNULE9BQU9xQixLQUFLO3dEQUFDYixJQUFHO3dEQUFLQyxXQUFVO2tFQUFrRDs7Ozs7O2tFQUlsRixRQUFDYTtrRUFBRTs7Ozs7O2tFQUNILFFBQUNDOzs7OztrRUFDRCxRQUFDRDtrRUFBRTs7Ozs7O2tFQUNILFFBQUNDOzs7OztrRUFDRCxRQUFDRDtrRUFBRTs7Ozs7O2tFQUNILFFBQUNDOzs7OztrRUFDRCxRQUFDRDtrRUFBRTs7Ozs7O2tFQUNILFFBQUNDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7a0RBSWIsUUFBQ0o7d0NBQUlWLFdBQVU7a0RBQ1gsY0FBQSxRQUFDZTs0Q0FDR0MsTUFBSzs0Q0FDTEMsSUFBRzs0Q0FDSGpCLFdBQVU7NENBQ1ZrQixTQUFTLElBQU12QixVQUFVOzRDQUN6QndCLEtBQUt2QjtzREFDUjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQVdyQztHQXBFU0g7S0FBQUE7QUFzRVQsZUFBZUEsYUFBYSJ9