import { createHotContext as __vite__createHotContext } from "/resonant-landscapes/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ParkModal.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/resonant-landscapes/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/resonant-landscapes/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88dff54b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/resonant-landscapes/node_modules/.vite/deps/react.js?v=88dff54b"; const Fragment = __vite__cjsImport2_react["Fragment"]; const useRef = __vite__cjsImport2_react["useRef"]; const memo = __vite__cjsImport2_react["memo"]; const lazy = __vite__cjsImport2_react["lazy"];
import { Dialog, Transition } from "/resonant-landscapes/node_modules/.vite/deps/@headlessui_react.js?v=88dff54b";
import { useAudioContext } from "/resonant-landscapes/src/contexts/AudioContextProvider.tsx";
const HOARenderer = /*#__PURE__*/ lazy(()=>import("/resonant-landscapes/src/components/HoaRenderer.tsx"));
_c = HOARenderer;
function ParkModal({ setIsOpen, isOpen, parkName, parkDistance, userOrientation }) {
    _s();
    const { stopSound } = useAudioContext();
    const cancelButtonRef = useRef(null);
    function cancel() {
        console.log('Cancelling...');
        stopSound();
        setIsOpen(false);
    }
    return /*#__PURE__*/ _jsxDEV(Transition.Root, {
        show: isOpen,
        as: Fragment,
        children: /*#__PURE__*/ _jsxDEV(Dialog, {
            as: "div",
            className: "relative z-10",
            initialFocus: cancelButtonRef,
            onClose: setIsOpen,
            children: [
                /*#__PURE__*/ _jsxDEV(Transition.Child, {
                    as: Fragment,
                    enter: "ease-out duration-300",
                    enterFrom: "opacity-0",
                    enterTo: "opacity-100",
                    leave: "ease-in duration-200",
                    leaveFrom: "opacity-100",
                    leaveTo: "opacity-0",
                    children: /*#__PURE__*/ _jsxDEV("div", {
                        className: "fixed inset-0 bg-gray-500 bg-opacity-10 transition-opacity"
                    }, void 0, false, {
                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx",
                        lineNumber: 30,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx",
                    lineNumber: 21,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ _jsxDEV("div", {
                    className: "relative inset-0 z-10 w-screen overflow-y-auto",
                    children: /*#__PURE__*/ _jsxDEV("div", {
                        className: "flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0",
                        children: /*#__PURE__*/ _jsxDEV(Transition.Child, {
                            as: Fragment,
                            enter: "ease-out duration-300",
                            enterFrom: "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                            enterTo: "opacity-100 translate-y-0 sm:scale-100",
                            leave: "ease-in duration-200",
                            leaveFrom: "opacity-100 translate-y-0 sm:scale-100",
                            leaveTo: "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                            children: /*#__PURE__*/ _jsxDEV(Dialog.Panel, {
                                className: "relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4",
                                        children: /*#__PURE__*/ _jsxDEV("div", {
                                            className: "sm:flex sm:items-start",
                                            children: /*#__PURE__*/ _jsxDEV("div", {
                                                className: "mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left",
                                                children: [
                                                    /*#__PURE__*/ _jsxDEV(Dialog.Title, {
                                                        as: "h3",
                                                        className: "text-base font-semibold leading-6 text-gray-900",
                                                        children: parkName
                                                    }, void 0, false, {
                                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx",
                                                        lineNumber: 48,
                                                        columnNumber: 45
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("p", {
                                                        className: "text-sm text-gray-500",
                                                        children: [
                                                            Math.floor(parkDistance),
                                                            " meters away"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx",
                                                        lineNumber: 51,
                                                        columnNumber: 45
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("div", {
                                                        className: "mt-2",
                                                        children: /*#__PURE__*/ _jsxDEV(HOARenderer, {
                                                            parkName: parkName,
                                                            parkDistance: parkDistance,
                                                            userOrientation: userOrientation
                                                        }, void 0, false, {
                                                            fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx",
                                                            lineNumber: 55,
                                                            columnNumber: 49
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx",
                                                        lineNumber: 54,
                                                        columnNumber: 45
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx",
                                                lineNumber: 47,
                                                columnNumber: 41
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx",
                                            lineNumber: 46,
                                            columnNumber: 37
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx",
                                        lineNumber: 45,
                                        columnNumber: 33
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "bg-gray-50 px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6",
                                        children: /*#__PURE__*/ _jsxDEV("button", {
                                            type: "button",
                                            className: "mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 sm:mt-0 sm:w-auto",
                                            onClick: cancel,
                                            ref: cancelButtonRef,
                                            children: "Close"
                                        }, void 0, false, {
                                            fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx",
                                            lineNumber: 62,
                                            columnNumber: 37
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx",
                                        lineNumber: 60,
                                        columnNumber: 33
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx",
                                lineNumber: 44,
                                columnNumber: 29
                            }, this)
                        }, void 0, false, {
                            fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx",
                            lineNumber: 35,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx",
                        lineNumber: 34,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx",
                    lineNumber: 33,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx",
            lineNumber: 20,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx",
        lineNumber: 19,
        columnNumber: 9
    }, this);
}
_s(ParkModal, "VxBqLUjbtl38ItQRDIpLPyYvUdU=", false, function() {
    return [
        useAudioContext
    ];
});
_c1 = ParkModal;
export default /*#__PURE__*/ _c2 = memo(ParkModal);
var _c, _c1, _c2;
$RefreshReg$(_c, "HOARenderer");
$RefreshReg$(_c1, "ParkModal");
$RefreshReg$(_c2, "%default%");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/ParkModal.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlBhcmtNb2RhbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRnJhZ21lbnQsIHVzZVJlZiwgbWVtbywgbGF6eSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgRGlhbG9nLCBUcmFuc2l0aW9uIH0gZnJvbSAnQGhlYWRsZXNzdWkvcmVhY3QnXG5pbXBvcnQgeyB1c2VBdWRpb0NvbnRleHQgfSBmcm9tIFwiLi4vY29udGV4dHMvQXVkaW9Db250ZXh0UHJvdmlkZXJcIjtcblxuY29uc3QgSE9BUmVuZGVyZXIgPSBsYXp5KCgpID0+IGltcG9ydCgnLi9Ib2FSZW5kZXJlcicpKTtcblxuZnVuY3Rpb24gUGFya01vZGFsKHsgc2V0SXNPcGVuLCBpc09wZW4sIHBhcmtOYW1lLCBwYXJrRGlzdGFuY2UsIHVzZXJPcmllbnRhdGlvbiB9KSB7XG4gICAgY29uc3QgeyBzdG9wU291bmQgfSA9IHVzZUF1ZGlvQ29udGV4dCgpO1xuXG4gICAgY29uc3QgY2FuY2VsQnV0dG9uUmVmID0gdXNlUmVmKG51bGwpO1xuXG5cbiAgICBmdW5jdGlvbiBjYW5jZWwoKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdDYW5jZWxsaW5nLi4uJyk7XG4gICAgICAgIHN0b3BTb3VuZCgpO1xuICAgICAgICBzZXRJc09wZW4oZmFsc2UpO1xuICAgIH1cbiAgICByZXR1cm4gKFxuICAgICAgICA8VHJhbnNpdGlvbi5Sb290IHNob3c9e2lzT3Blbn0gYXM9e0ZyYWdtZW50fT5cbiAgICAgICAgICAgIDxEaWFsb2cgYXM9XCJkaXZcIiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwXCIgaW5pdGlhbEZvY3VzPXtjYW5jZWxCdXR0b25SZWZ9IG9uQ2xvc2U9e3NldElzT3Blbn0+XG4gICAgICAgICAgICAgICAgPFRyYW5zaXRpb24uQ2hpbGRcbiAgICAgICAgICAgICAgICAgICAgYXM9e0ZyYWdtZW50fVxuICAgICAgICAgICAgICAgICAgICBlbnRlcj1cImVhc2Utb3V0IGR1cmF0aW9uLTMwMFwiXG4gICAgICAgICAgICAgICAgICAgIGVudGVyRnJvbT1cIm9wYWNpdHktMFwiXG4gICAgICAgICAgICAgICAgICAgIGVudGVyVG89XCJvcGFjaXR5LTEwMFwiXG4gICAgICAgICAgICAgICAgICAgIGxlYXZlPVwiZWFzZS1pbiBkdXJhdGlvbi0yMDBcIlxuICAgICAgICAgICAgICAgICAgICBsZWF2ZUZyb209XCJvcGFjaXR5LTEwMFwiXG4gICAgICAgICAgICAgICAgICAgIGxlYXZlVG89XCJvcGFjaXR5LTBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWdyYXktNTAwIGJnLW9wYWNpdHktMTAgdHJhbnNpdGlvbi1vcGFjaXR5XCIgLz5cbiAgICAgICAgICAgICAgICA8L1RyYW5zaXRpb24uQ2hpbGQ+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGluc2V0LTAgei0xMCB3LXNjcmVlbiBvdmVyZmxvdy15LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLWZ1bGwgaXRlbXMtZW5kIGp1c3RpZnktY2VudGVyIHAtNCB0ZXh0LWNlbnRlciBzbTppdGVtcy1jZW50ZXIgc206cC0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8VHJhbnNpdGlvbi5DaGlsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFzPXtGcmFnbWVudH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbnRlcj1cImVhc2Utb3V0IGR1cmF0aW9uLTMwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZW50ZXJGcm9tPVwib3BhY2l0eS0wIHRyYW5zbGF0ZS15LTQgc206dHJhbnNsYXRlLXktMCBzbTpzY2FsZS05NVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZW50ZXJUbz1cIm9wYWNpdHktMTAwIHRyYW5zbGF0ZS15LTAgc206c2NhbGUtMTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWF2ZT1cImVhc2UtaW4gZHVyYXRpb24tMjAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWF2ZUZyb209XCJvcGFjaXR5LTEwMCB0cmFuc2xhdGUteS0wIHNtOnNjYWxlLTEwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGVhdmVUbz1cIm9wYWNpdHktMCB0cmFuc2xhdGUteS00IHNtOnRyYW5zbGF0ZS15LTAgc206c2NhbGUtOTVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEaWFsb2cuUGFuZWwgY2xhc3NOYW1lPVwicmVsYXRpdmUgdHJhbnNmb3JtIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLWxnIGJnLXdoaXRlIHRleHQtbGVmdCBzaGFkb3cteGwgdHJhbnNpdGlvbi1hbGwgc206bXktOCBzbTp3LWZ1bGwgc206bWF4LXctbGdcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBweC00IHBiLTQgcHQtNSBzbTpwLTYgc206cGItNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpmbGV4IHNtOml0ZW1zLXN0YXJ0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIHRleHQtY2VudGVyIHNtOm1sLTQgc206bXQtMCBzbTp0ZXh0LWxlZnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERpYWxvZy5UaXRsZSBhcz1cImgzXCIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgbGVhZGluZy02IHRleHQtZ3JheS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwYXJrTmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9EaWFsb2cuVGl0bGU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge01hdGguZmxvb3IocGFya0Rpc3RhbmNlKX0gbWV0ZXJzIGF3YXlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxIT0FSZW5kZXJlciBwYXJrTmFtZT17cGFya05hbWV9IHBhcmtEaXN0YW5jZT17cGFya0Rpc3RhbmNlfSB1c2VyT3JpZW50YXRpb249e3VzZXJPcmllbnRhdGlvbn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBweC00IHB5LTMgc206ZmxleCBzbTpmbGV4LXJvdy1yZXZlcnNlIHNtOnB4LTZcIj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTMgaW5saW5lLWZsZXggdy1mdWxsIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbWQgYmctd2hpdGUgcHgtMyBweS0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHNoYWRvdy1zbSByaW5nLTEgcmluZy1pbnNldCByaW5nLWdyYXktMzAwIGhvdmVyOmJnLWdyYXktNTAgc206bXQtMCBzbTp3LWF1dG9cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2NhbmNlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWY9e2NhbmNlbEJ1dHRvblJlZn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDbG9zZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRGlhbG9nLlBhbmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9UcmFuc2l0aW9uLkNoaWxkPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvRGlhbG9nPlxuICAgICAgICA8L1RyYW5zaXRpb24uUm9vdD5cbiAgICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IG1lbW8oUGFya01vZGFsKSJdLCJuYW1lcyI6WyJGcmFnbWVudCIsInVzZVJlZiIsIm1lbW8iLCJsYXp5IiwiRGlhbG9nIiwiVHJhbnNpdGlvbiIsInVzZUF1ZGlvQ29udGV4dCIsIkhPQVJlbmRlcmVyIiwiUGFya01vZGFsIiwic2V0SXNPcGVuIiwiaXNPcGVuIiwicGFya05hbWUiLCJwYXJrRGlzdGFuY2UiLCJ1c2VyT3JpZW50YXRpb24iLCJzdG9wU291bmQiLCJjYW5jZWxCdXR0b25SZWYiLCJjYW5jZWwiLCJjb25zb2xlIiwibG9nIiwiUm9vdCIsInNob3ciLCJhcyIsImNsYXNzTmFtZSIsImluaXRpYWxGb2N1cyIsIm9uQ2xvc2UiLCJDaGlsZCIsImVudGVyIiwiZW50ZXJGcm9tIiwiZW50ZXJUbyIsImxlYXZlIiwibGVhdmVGcm9tIiwibGVhdmVUbyIsImRpdiIsIlBhbmVsIiwiVGl0bGUiLCJwIiwiTWF0aCIsImZsb29yIiwiYnV0dG9uIiwidHlwZSIsIm9uQ2xpY2siLCJyZWYiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQSxTQUFTQSxRQUFRLEVBQUVDLE1BQU0sRUFBRUMsSUFBSSxFQUFFQyxJQUFJLFFBQVEsUUFBTztBQUNwRCxTQUFTQyxNQUFNLEVBQUVDLFVBQVUsUUFBUSxvQkFBbUI7QUFDdEQsU0FBU0MsZUFBZSxRQUFRLG1DQUFtQztBQUVuRSxNQUFNQyw0QkFBY0osS0FBSyxJQUFNLE1BQU0sQ0FBQztLQUFoQ0k7QUFFTixTQUFTQyxVQUFVLEVBQUVDLFNBQVMsRUFBRUMsTUFBTSxFQUFFQyxRQUFRLEVBQUVDLFlBQVksRUFBRUMsZUFBZSxFQUFFOztJQUM3RSxNQUFNLEVBQUVDLFNBQVMsRUFBRSxHQUFHUjtJQUV0QixNQUFNUyxrQkFBa0JkLE9BQU87SUFHL0IsU0FBU2U7UUFDTEMsUUFBUUMsR0FBRyxDQUFDO1FBQ1pKO1FBQ0FMLFVBQVU7SUFDZDtJQUNBLHFCQUNJLFFBQUNKLFdBQVdjLElBQUk7UUFBQ0MsTUFBTVY7UUFBUVcsSUFBSXJCO2tCQUMvQixjQUFBLFFBQUNJO1lBQU9pQixJQUFHO1lBQU1DLFdBQVU7WUFBZ0JDLGNBQWNSO1lBQWlCUyxTQUFTZjs7OEJBQy9FLFFBQUNKLFdBQVdvQixLQUFLO29CQUNiSixJQUFJckI7b0JBQ0owQixPQUFNO29CQUNOQyxXQUFVO29CQUNWQyxTQUFRO29CQUNSQyxPQUFNO29CQUNOQyxXQUFVO29CQUNWQyxTQUFROzhCQUVSLGNBQUEsUUFBQ0M7d0JBQUlWLFdBQVU7Ozs7Ozs7Ozs7OzhCQUduQixRQUFDVTtvQkFBSVYsV0FBVTs4QkFDWCxjQUFBLFFBQUNVO3dCQUFJVixXQUFVO2tDQUNYLGNBQUEsUUFBQ2pCLFdBQVdvQixLQUFLOzRCQUNiSixJQUFJckI7NEJBQ0owQixPQUFNOzRCQUNOQyxXQUFVOzRCQUNWQyxTQUFROzRCQUNSQyxPQUFNOzRCQUNOQyxXQUFVOzRCQUNWQyxTQUFRO3NDQUVSLGNBQUEsUUFBQzNCLE9BQU82QixLQUFLO2dDQUFDWCxXQUFVOztrREFDcEIsUUFBQ1U7d0NBQUlWLFdBQVU7a0RBQ1gsY0FBQSxRQUFDVTs0Q0FBSVYsV0FBVTtzREFDWCxjQUFBLFFBQUNVO2dEQUFJVixXQUFVOztrRUFDWCxRQUFDbEIsT0FBTzhCLEtBQUs7d0RBQUNiLElBQUc7d0RBQUtDLFdBQVU7a0VBQzNCWDs7Ozs7O2tFQUVMLFFBQUN3Qjt3REFBRWIsV0FBVTs7NERBQ1JjLEtBQUtDLEtBQUssQ0FBQ3pCOzREQUFjOzs7Ozs7O2tFQUU5QixRQUFDb0I7d0RBQUlWLFdBQVU7a0VBQ1gsY0FBQSxRQUFDZjs0REFBWUksVUFBVUE7NERBQVVDLGNBQWNBOzREQUFjQyxpQkFBaUJBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7a0RBSzlGLFFBQUNtQjt3Q0FBSVYsV0FBVTtrREFFWCxjQUFBLFFBQUNnQjs0Q0FDR0MsTUFBSzs0Q0FDTGpCLFdBQVU7NENBQ1ZrQixTQUFTeEI7NENBQ1R5QixLQUFLMUI7c0RBQ1I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFXckM7R0F2RVNQOztRQUNpQkY7OztNQURqQkU7QUF5RVQsbUNBQWVOLEtBQUtNLFdBQVUifQ==