import { createHotContext as __vite__createHotContext } from "/resonant-landscapes/@vite/client";import.meta.hot = __vite__createHotContext("/src/contexts/AudioContextProvider.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/contexts/AudioContextProvider.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/resonant-landscapes/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/resonant-landscapes/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88dff54b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s1 = $RefreshSig$();
import __vite__cjsImport2_react from "/resonant-landscapes/node_modules/.vite/deps/react.js?v=88dff54b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react; const createContext = __vite__cjsImport2_react["createContext"]; const useState = __vite__cjsImport2_react["useState"]; const useEffect = __vite__cjsImport2_react["useEffect"]; const useContext = __vite__cjsImport2_react["useContext"]; const useRef = __vite__cjsImport2_react["useRef"];
import __vite__cjsImport3_resonanceAudio from "/resonant-landscapes/node_modules/.vite/deps/resonance-audio.js?v=88dff54b"; const ResonanceAudio = __vite__cjsImport3_resonanceAudio["ResonanceAudio"];
import Omnitone from "/resonant-landscapes/node_modules/.vite/deps/omnitone_build_omnitone__min__esm__js.js?v=88dff54b";
// Creating the context with an extended initial value
const AudioContextState = /*#__PURE__*/ createContext({
    audioContext: null,
    resonanceAudioScene: null,
    playSound: (buffer)=>{},
    stopSound: ()=>{},
    isLoading: false,
    setIsLoading: (boolean)=>{},
    isPlaying: false,
    setIsPlaying: (boolean)=>{},
    buffers: [],
    loadBuffers: (urls)=>{},
    setBuffers: (buffers)=>{},
    bufferSourceRef: null
});
const AudioContextProvider = ({ children })=>{
    _s();
    const [audioContext, setAudioContext] = useState(null);
    const [resonanceAudioScene, setResonanceAudioScene] = useState(null);
    const [buffers, setBuffers] = useState([]);
    const [isPlaying, setIsPlaying] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const bufferSourceRef = useRef(null);
    const loadBuffers = async (urls)=>{
        if (!audioContext || !resonanceAudioScene || !urls.length) {
            console.error("Missing audio context, resonance scene, or URLs.");
            return;
        }
        setIsLoading(true);
        Omnitone.createBufferList(audioContext, urls).then((results)=>{
            console.log("Results", results);
            const contentBuffer = Omnitone.mergeBufferListByChannel(audioContext, results); // Adjust if needed
            setBuffers(contentBuffer); // Ensure buffers is set with the correct format, wrapped in an array if necessary
            setIsLoading(false); // Update loading state
        }).catch((error)=>{
            console.error("Error loading buffers with Omnitone:", error);
            // setLoadError(error); // Update state to reflect loading error
            setIsLoading(false); // Ensure loading state is updated even in case of error
        });
    };
    // Function to play sound
    const playSound = ()=>{
        if (!audioContext || !resonanceAudioScene || isPlaying) return;
        console.log('Playing sound...', buffers);
        const source = resonanceAudioScene.createSource();
        const bufferSource = audioContext.createBufferSource();
        bufferSourceRef.current = bufferSource;
        bufferSource.buffer = buffers;
        bufferSource.loop = true;
        bufferSource.connect(source.input);
        bufferSource.start();
        setIsPlaying(true);
    };
    // Function to stop sound
    const stopSound = ()=>{
        if (bufferSourceRef.current && isPlaying) {
            console.log('Stopping sound...');
            bufferSourceRef.current.stop();
            // bufferSourceRef.current.buffer = null;
            bufferSourceRef.current.disconnect();
            setIsPlaying(false);
        }
    };
    // Cleanup method to free up buffer memory
    const cleanupBuffers = ()=>{
        if (buffers.length > 0) {
            // Assuming buffers is an array of AudioBuffer or similar
            setBuffers([]); // Clearing the buffers array
        }
    // Additional cleanup logic if needed
    };
    useEffect(()=>{
        const initAudio = async ()=>{
            try {
                const context = new (window.AudioContext || window.webkitAudioContext)();
                setAudioContext(context);
                const scene = new ResonanceAudio(context);
                scene.setAmbisonicOrder(2);
                setResonanceAudioScene(scene);
                scene.output.connect(context.destination);
            } catch (error) {
                console.error('Error initializing audio:', error);
            }
        };
        initAudio();
        return ()=>{
            if (audioContext) {
                audioContext.close();
            }
            if (resonanceAudioScene) {
                resonanceAudioScene.dispose();
            }
            cleanupBuffers();
        };
    }, []);
    return /*#__PURE__*/ _jsxDEV(AudioContextState.Provider, {
        value: {
            audioContext,
            resonanceAudioScene,
            bufferSourceRef,
            playSound,
            stopSound,
            loadBuffers,
            isLoading,
            setIsLoading,
            isPlaying,
            setIsPlaying,
            buffers,
            setBuffers
        },
        children: children
    }, void 0, false, {
        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/contexts/AudioContextProvider.tsx",
        lineNumber: 124,
        columnNumber: 9
    }, this);
};
_s(AudioContextProvider, "o60YGWkI9RD0IqKOQjqvlLKZKaw=");
_c = AudioContextProvider;
export default AudioContextProvider;
export const useAudioContext = ()=>{
    _s1();
    return useContext(AudioContextState);
};
_s1(useAudioContext, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c;
$RefreshReg$(_c, "AudioContextProvider");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/contexts/AudioContextProvider.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/contexts/AudioContextProvider.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkF1ZGlvQ29udGV4dFByb3ZpZGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgY3JlYXRlQ29udGV4dCwgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlQ29udGV4dCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgUmVzb25hbmNlQXVkaW8gfSBmcm9tIFwicmVzb25hbmNlLWF1ZGlvXCI7XG5pbXBvcnQgT21uaXRvbmUgZnJvbSAnb21uaXRvbmUvYnVpbGQvb21uaXRvbmUubWluLmVzbS5qcyc7XG5cbi8vIENyZWF0aW5nIHRoZSBjb250ZXh0IHdpdGggYW4gZXh0ZW5kZWQgaW5pdGlhbCB2YWx1ZVxuY29uc3QgQXVkaW9Db250ZXh0U3RhdGUgPSBjcmVhdGVDb250ZXh0KHtcbiAgICBhdWRpb0NvbnRleHQ6IG51bGwsXG4gICAgcmVzb25hbmNlQXVkaW9TY2VuZTogbnVsbCwgLy8gQWRkIHRoZSBSZXNvbmFuY2VBdWRpbyBzY2VuZSB0byB0aGUgY29udGV4dFxuICAgIHBsYXlTb3VuZDogKGJ1ZmZlcikgPT4geyB9LFxuICAgIHN0b3BTb3VuZDogKCkgPT4geyB9LFxuICAgIGlzTG9hZGluZzogZmFsc2UsXG4gICAgc2V0SXNMb2FkaW5nOiAoYm9vbGVhbikgPT4geyB9LFxuICAgIGlzUGxheWluZzogZmFsc2UsXG4gICAgc2V0SXNQbGF5aW5nOiAoYm9vbGVhbikgPT4geyB9LFxuICAgIGJ1ZmZlcnM6IFtdLFxuICAgIGxvYWRCdWZmZXJzOiAodXJscykgPT4geyB9LFxuICAgIHNldEJ1ZmZlcnM6IChidWZmZXJzKSA9PiB7IH0sXG4gICAgYnVmZmVyU291cmNlUmVmOiBudWxsXG59KTtcblxuXG5jb25zdCBBdWRpb0NvbnRleHRQcm92aWRlciA9ICh7IGNoaWxkcmVuIH0pID0+IHtcbiAgICBjb25zdCBbYXVkaW9Db250ZXh0LCBzZXRBdWRpb0NvbnRleHRdID0gdXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgW3Jlc29uYW5jZUF1ZGlvU2NlbmUsIHNldFJlc29uYW5jZUF1ZGlvU2NlbmVdID0gdXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgW2J1ZmZlcnMsIHNldEJ1ZmZlcnNdID0gdXNlU3RhdGUoW10pO1xuICAgIGNvbnN0IFtpc1BsYXlpbmcsIHNldElzUGxheWluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBidWZmZXJTb3VyY2VSZWYgPSB1c2VSZWYobnVsbCk7XG5cbiAgICBjb25zdCBsb2FkQnVmZmVycyA9IGFzeW5jICh1cmxzKSA9PiB7XG4gICAgICAgIGlmICghYXVkaW9Db250ZXh0IHx8ICFyZXNvbmFuY2VBdWRpb1NjZW5lIHx8ICF1cmxzLmxlbmd0aCkge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIk1pc3NpbmcgYXVkaW8gY29udGV4dCwgcmVzb25hbmNlIHNjZW5lLCBvciBVUkxzLlwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcblxuICAgICAgICBPbW5pdG9uZS5jcmVhdGVCdWZmZXJMaXN0KGF1ZGlvQ29udGV4dCwgdXJscylcbiAgICAgICAgICAgIC50aGVuKChyZXN1bHRzKSA9PiB7XG5cbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlJlc3VsdHNcIiwgcmVzdWx0cylcbiAgICAgICAgICAgICAgICBjb25zdCBjb250ZW50QnVmZmVyID0gT21uaXRvbmUubWVyZ2VCdWZmZXJMaXN0QnlDaGFubmVsKGF1ZGlvQ29udGV4dCwgcmVzdWx0cyk7IC8vIEFkanVzdCBpZiBuZWVkZWRcblxuICAgICAgICAgICAgICAgIHNldEJ1ZmZlcnMoY29udGVudEJ1ZmZlcik7IC8vIEVuc3VyZSBidWZmZXJzIGlzIHNldCB3aXRoIHRoZSBjb3JyZWN0IGZvcm1hdCwgd3JhcHBlZCBpbiBhbiBhcnJheSBpZiBuZWNlc3NhcnlcbiAgICAgICAgICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpOyAvLyBVcGRhdGUgbG9hZGluZyBzdGF0ZVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5jYXRjaCgoZXJyb3IpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgbG9hZGluZyBidWZmZXJzIHdpdGggT21uaXRvbmU6XCIsIGVycm9yKTtcbiAgICAgICAgICAgICAgICAvLyBzZXRMb2FkRXJyb3IoZXJyb3IpOyAvLyBVcGRhdGUgc3RhdGUgdG8gcmVmbGVjdCBsb2FkaW5nIGVycm9yXG4gICAgICAgICAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTsgLy8gRW5zdXJlIGxvYWRpbmcgc3RhdGUgaXMgdXBkYXRlZCBldmVuIGluIGNhc2Ugb2YgZXJyb3JcbiAgICAgICAgICAgIH0pO1xuICAgIH07XG5cblxuXG4gICAgLy8gRnVuY3Rpb24gdG8gcGxheSBzb3VuZFxuICAgIGNvbnN0IHBsYXlTb3VuZCA9ICgpID0+IHtcbiAgICAgICAgaWYgKCFhdWRpb0NvbnRleHQgfHwgIXJlc29uYW5jZUF1ZGlvU2NlbmUgfHwgaXNQbGF5aW5nKSByZXR1cm47XG5cbiAgICAgICAgY29uc29sZS5sb2coJ1BsYXlpbmcgc291bmQuLi4nLCBidWZmZXJzKTtcbiAgICAgICAgY29uc3Qgc291cmNlID0gcmVzb25hbmNlQXVkaW9TY2VuZS5jcmVhdGVTb3VyY2UoKTtcbiAgICAgICAgY29uc3QgYnVmZmVyU291cmNlID0gYXVkaW9Db250ZXh0LmNyZWF0ZUJ1ZmZlclNvdXJjZSgpO1xuICAgICAgICBidWZmZXJTb3VyY2VSZWYuY3VycmVudCA9IGJ1ZmZlclNvdXJjZTtcbiAgICAgICAgYnVmZmVyU291cmNlLmJ1ZmZlciA9IGJ1ZmZlcnM7XG4gICAgICAgIGJ1ZmZlclNvdXJjZS5sb29wID0gdHJ1ZTtcbiAgICAgICAgYnVmZmVyU291cmNlLmNvbm5lY3Qoc291cmNlLmlucHV0KTtcbiAgICAgICAgYnVmZmVyU291cmNlLnN0YXJ0KCk7XG4gICAgICAgIHNldElzUGxheWluZyh0cnVlKTtcbiAgICB9O1xuXG4gICAgLy8gRnVuY3Rpb24gdG8gc3RvcCBzb3VuZFxuICAgIGNvbnN0IHN0b3BTb3VuZCA9ICgpID0+IHtcbiAgICAgICAgaWYgKGJ1ZmZlclNvdXJjZVJlZi5jdXJyZW50ICYmIGlzUGxheWluZykge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ1N0b3BwaW5nIHNvdW5kLi4uJyk7XG4gICAgICAgICAgICBidWZmZXJTb3VyY2VSZWYuY3VycmVudC5zdG9wKCk7XG4gICAgICAgICAgICAvLyBidWZmZXJTb3VyY2VSZWYuY3VycmVudC5idWZmZXIgPSBudWxsO1xuICAgICAgICAgICAgYnVmZmVyU291cmNlUmVmLmN1cnJlbnQuZGlzY29ubmVjdCgpXG4gICAgICAgICAgICBzZXRJc1BsYXlpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIC8vIENsZWFudXAgbWV0aG9kIHRvIGZyZWUgdXAgYnVmZmVyIG1lbW9yeVxuICAgIGNvbnN0IGNsZWFudXBCdWZmZXJzID0gKCkgPT4ge1xuICAgICAgICBpZiAoYnVmZmVycy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAvLyBBc3N1bWluZyBidWZmZXJzIGlzIGFuIGFycmF5IG9mIEF1ZGlvQnVmZmVyIG9yIHNpbWlsYXJcbiAgICAgICAgICAgIHNldEJ1ZmZlcnMoW10pOyAvLyBDbGVhcmluZyB0aGUgYnVmZmVycyBhcnJheVxuICAgICAgICB9XG4gICAgICAgIC8vIEFkZGl0aW9uYWwgY2xlYW51cCBsb2dpYyBpZiBuZWVkZWRcbiAgICB9O1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgaW5pdEF1ZGlvID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCBjb250ZXh0ID0gbmV3ICh3aW5kb3cuQXVkaW9Db250ZXh0IHx8IHdpbmRvdy53ZWJraXRBdWRpb0NvbnRleHQpKCk7XG4gICAgICAgICAgICAgICAgc2V0QXVkaW9Db250ZXh0KGNvbnRleHQpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHNjZW5lID0gbmV3IFJlc29uYW5jZUF1ZGlvKGNvbnRleHQpO1xuICAgICAgICAgICAgICAgIHNjZW5lLnNldEFtYmlzb25pY09yZGVyKDIpXG4gICAgICAgICAgICAgICAgc2V0UmVzb25hbmNlQXVkaW9TY2VuZShzY2VuZSk7XG4gICAgICAgICAgICAgICAgc2NlbmUub3V0cHV0LmNvbm5lY3QoY29udGV4dC5kZXN0aW5hdGlvbik7XG5cbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG5cbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBpbml0aWFsaXppbmcgYXVkaW86JywgZXJyb3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIGluaXRBdWRpbygpO1xuXG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICBpZiAoYXVkaW9Db250ZXh0KSB7XG4gICAgICAgICAgICAgICAgYXVkaW9Db250ZXh0LmNsb3NlKCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChyZXNvbmFuY2VBdWRpb1NjZW5lKSB7XG4gICAgICAgICAgICAgICAgcmVzb25hbmNlQXVkaW9TY2VuZS5kaXNwb3NlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjbGVhbnVwQnVmZmVycygpO1xuICAgICAgICB9O1xuXG4gICAgfSwgW10pO1xuXG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8QXVkaW9Db250ZXh0U3RhdGUuUHJvdmlkZXIgdmFsdWU9e3tcbiAgICAgICAgICAgIGF1ZGlvQ29udGV4dCwgcmVzb25hbmNlQXVkaW9TY2VuZSwgYnVmZmVyU291cmNlUmVmLFxuICAgICAgICAgICAgcGxheVNvdW5kLCBzdG9wU291bmQsIGxvYWRCdWZmZXJzLCBpc0xvYWRpbmcsIHNldElzTG9hZGluZywgaXNQbGF5aW5nLCBzZXRJc1BsYXlpbmcsIGJ1ZmZlcnMsIHNldEJ1ZmZlcnNcbiAgICAgICAgfX0+XG4gICAgICAgICAgICB7Y2hpbGRyZW59XG4gICAgICAgIDwvQXVkaW9Db250ZXh0U3RhdGUuUHJvdmlkZXI+XG4gICAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IEF1ZGlvQ29udGV4dFByb3ZpZGVyO1xuXG5leHBvcnQgY29uc3QgdXNlQXVkaW9Db250ZXh0ID0gKCkgPT4gdXNlQ29udGV4dChBdWRpb0NvbnRleHRTdGF0ZSk7XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJjcmVhdGVDb250ZXh0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VDb250ZXh0IiwidXNlUmVmIiwiUmVzb25hbmNlQXVkaW8iLCJPbW5pdG9uZSIsIkF1ZGlvQ29udGV4dFN0YXRlIiwiYXVkaW9Db250ZXh0IiwicmVzb25hbmNlQXVkaW9TY2VuZSIsInBsYXlTb3VuZCIsImJ1ZmZlciIsInN0b3BTb3VuZCIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsImJvb2xlYW4iLCJpc1BsYXlpbmciLCJzZXRJc1BsYXlpbmciLCJidWZmZXJzIiwibG9hZEJ1ZmZlcnMiLCJ1cmxzIiwic2V0QnVmZmVycyIsImJ1ZmZlclNvdXJjZVJlZiIsIkF1ZGlvQ29udGV4dFByb3ZpZGVyIiwiY2hpbGRyZW4iLCJzZXRBdWRpb0NvbnRleHQiLCJzZXRSZXNvbmFuY2VBdWRpb1NjZW5lIiwibGVuZ3RoIiwiY29uc29sZSIsImVycm9yIiwiY3JlYXRlQnVmZmVyTGlzdCIsInRoZW4iLCJyZXN1bHRzIiwibG9nIiwiY29udGVudEJ1ZmZlciIsIm1lcmdlQnVmZmVyTGlzdEJ5Q2hhbm5lbCIsImNhdGNoIiwic291cmNlIiwiY3JlYXRlU291cmNlIiwiYnVmZmVyU291cmNlIiwiY3JlYXRlQnVmZmVyU291cmNlIiwiY3VycmVudCIsImxvb3AiLCJjb25uZWN0IiwiaW5wdXQiLCJzdGFydCIsInN0b3AiLCJkaXNjb25uZWN0IiwiY2xlYW51cEJ1ZmZlcnMiLCJpbml0QXVkaW8iLCJjb250ZXh0Iiwid2luZG93IiwiQXVkaW9Db250ZXh0Iiwid2Via2l0QXVkaW9Db250ZXh0Iiwic2NlbmUiLCJzZXRBbWJpc29uaWNPcmRlciIsIm91dHB1dCIsImRlc3RpbmF0aW9uIiwiY2xvc2UiLCJkaXNwb3NlIiwiUHJvdmlkZXIiLCJ2YWx1ZSIsInVzZUF1ZGlvQ29udGV4dCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBLE9BQU9BLFNBQVNDLGFBQWEsRUFBRUMsUUFBUSxFQUFFQyxTQUFTLEVBQUVDLFVBQVUsRUFBRUMsTUFBTSxRQUFRLFFBQVE7QUFDdEYsU0FBU0MsY0FBYyxRQUFRLGtCQUFrQjtBQUNqRCxPQUFPQyxjQUFjLHFDQUFxQztBQUUxRCxzREFBc0Q7QUFDdEQsTUFBTUMsa0NBQW9CUCxjQUFjO0lBQ3BDUSxjQUFjO0lBQ2RDLHFCQUFxQjtJQUNyQkMsV0FBVyxDQUFDQyxVQUFhO0lBQ3pCQyxXQUFXLEtBQVE7SUFDbkJDLFdBQVc7SUFDWEMsY0FBYyxDQUFDQyxXQUFjO0lBQzdCQyxXQUFXO0lBQ1hDLGNBQWMsQ0FBQ0YsV0FBYztJQUM3QkcsU0FBUyxFQUFFO0lBQ1hDLGFBQWEsQ0FBQ0MsUUFBVztJQUN6QkMsWUFBWSxDQUFDSCxXQUFjO0lBQzNCSSxpQkFBaUI7QUFDckI7QUFHQSxNQUFNQyx1QkFBdUIsQ0FBQyxFQUFFQyxRQUFRLEVBQUU7O0lBQ3RDLE1BQU0sQ0FBQ2hCLGNBQWNpQixnQkFBZ0IsR0FBR3hCLFNBQVM7SUFDakQsTUFBTSxDQUFDUSxxQkFBcUJpQix1QkFBdUIsR0FBR3pCLFNBQVM7SUFDL0QsTUFBTSxDQUFDaUIsU0FBU0csV0FBVyxHQUFHcEIsU0FBUyxFQUFFO0lBQ3pDLE1BQU0sQ0FBQ2UsV0FBV0MsYUFBYSxHQUFHaEIsU0FBUztJQUMzQyxNQUFNLENBQUNZLFdBQVdDLGFBQWEsR0FBR2IsU0FBUztJQUMzQyxNQUFNcUIsa0JBQWtCbEIsT0FBTztJQUUvQixNQUFNZSxjQUFjLE9BQU9DO1FBQ3ZCLElBQUksQ0FBQ1osZ0JBQWdCLENBQUNDLHVCQUF1QixDQUFDVyxLQUFLTyxNQUFNLEVBQUU7WUFDdkRDLFFBQVFDLEtBQUssQ0FBQztZQUNkO1FBQ0o7UUFFQWYsYUFBYTtRQUViUixTQUFTd0IsZ0JBQWdCLENBQUN0QixjQUFjWSxNQUNuQ1csSUFBSSxDQUFDLENBQUNDO1lBRUhKLFFBQVFLLEdBQUcsQ0FBQyxXQUFXRDtZQUN2QixNQUFNRSxnQkFBZ0I1QixTQUFTNkIsd0JBQXdCLENBQUMzQixjQUFjd0IsVUFBVSxtQkFBbUI7WUFFbkdYLFdBQVdhLGdCQUFnQixrRkFBa0Y7WUFDN0dwQixhQUFhLFFBQVEsdUJBQXVCO1FBQ2hELEdBQ0NzQixLQUFLLENBQUMsQ0FBQ1A7WUFDSkQsUUFBUUMsS0FBSyxDQUFDLHdDQUF3Q0E7WUFDdEQsZ0VBQWdFO1lBQ2hFZixhQUFhLFFBQVEsd0RBQXdEO1FBQ2pGO0lBQ1I7SUFJQSx5QkFBeUI7SUFDekIsTUFBTUosWUFBWTtRQUNkLElBQUksQ0FBQ0YsZ0JBQWdCLENBQUNDLHVCQUF1Qk8sV0FBVztRQUV4RFksUUFBUUssR0FBRyxDQUFDLG9CQUFvQmY7UUFDaEMsTUFBTW1CLFNBQVM1QixvQkFBb0I2QixZQUFZO1FBQy9DLE1BQU1DLGVBQWUvQixhQUFhZ0Msa0JBQWtCO1FBQ3BEbEIsZ0JBQWdCbUIsT0FBTyxHQUFHRjtRQUMxQkEsYUFBYTVCLE1BQU0sR0FBR087UUFDdEJxQixhQUFhRyxJQUFJLEdBQUc7UUFDcEJILGFBQWFJLE9BQU8sQ0FBQ04sT0FBT08sS0FBSztRQUNqQ0wsYUFBYU0sS0FBSztRQUNsQjVCLGFBQWE7SUFDakI7SUFFQSx5QkFBeUI7SUFDekIsTUFBTUwsWUFBWTtRQUNkLElBQUlVLGdCQUFnQm1CLE9BQU8sSUFBSXpCLFdBQVc7WUFDdENZLFFBQVFLLEdBQUcsQ0FBQztZQUNaWCxnQkFBZ0JtQixPQUFPLENBQUNLLElBQUk7WUFDNUIseUNBQXlDO1lBQ3pDeEIsZ0JBQWdCbUIsT0FBTyxDQUFDTSxVQUFVO1lBQ2xDOUIsYUFBYTtRQUNqQjtJQUNKO0lBRUEsMENBQTBDO0lBQzFDLE1BQU0rQixpQkFBaUI7UUFDbkIsSUFBSTlCLFFBQVFTLE1BQU0sR0FBRyxHQUFHO1lBQ3BCLHlEQUF5RDtZQUN6RE4sV0FBVyxFQUFFLEdBQUcsNkJBQTZCO1FBQ2pEO0lBQ0EscUNBQXFDO0lBQ3pDO0lBRUFuQixVQUFVO1FBQ04sTUFBTStDLFlBQVk7WUFDZCxJQUFJO2dCQUNBLE1BQU1DLFVBQVUsSUFBS0MsQ0FBQUEsT0FBT0MsWUFBWSxJQUFJRCxPQUFPRSxrQkFBa0IsQUFBRDtnQkFDcEU1QixnQkFBZ0J5QjtnQkFDaEIsTUFBTUksUUFBUSxJQUFJakQsZUFBZTZDO2dCQUNqQ0ksTUFBTUMsaUJBQWlCLENBQUM7Z0JBQ3hCN0IsdUJBQXVCNEI7Z0JBQ3ZCQSxNQUFNRSxNQUFNLENBQUNiLE9BQU8sQ0FBQ08sUUFBUU8sV0FBVztZQUU1QyxFQUFFLE9BQU81QixPQUFPO2dCQUVaRCxRQUFRQyxLQUFLLENBQUMsNkJBQTZCQTtZQUMvQztRQUNKO1FBRUFvQjtRQUVBLE9BQU87WUFDSCxJQUFJekMsY0FBYztnQkFDZEEsYUFBYWtELEtBQUs7WUFDdEI7WUFFQSxJQUFJakQscUJBQXFCO2dCQUNyQkEsb0JBQW9Ca0QsT0FBTztZQUMvQjtZQUNBWDtRQUNKO0lBRUosR0FBRyxFQUFFO0lBR0wscUJBQ0ksUUFBQ3pDLGtCQUFrQnFELFFBQVE7UUFBQ0MsT0FBTztZQUMvQnJEO1lBQWNDO1lBQXFCYTtZQUNuQ1o7WUFBV0U7WUFBV087WUFBYU47WUFBV0M7WUFBY0U7WUFBV0M7WUFBY0M7WUFBU0c7UUFDbEc7a0JBQ0tHOzs7Ozs7QUFHYjtHQTdHTUQ7S0FBQUE7QUErR04sZUFBZUEscUJBQXFCO0FBRXBDLE9BQU8sTUFBTXVDLGtCQUFrQjs7SUFBTTNELE9BQUFBLFdBQVdJO0FBQWlCLEVBQUU7SUFBdER1RCJ9