import __vite__cjsImport0_react_jsxDevRuntime from "/resonant-landscapes/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88dff54b"; const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/resonant-landscapes/node_modules/.vite/deps/react.js?v=88dff54b"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/resonant-landscapes/node_modules/.vite/deps/react-dom_client.js?v=88dff54b"; const ReactDOM = __vite__cjsImport2_reactDom_client.__esModule ? __vite__cjsImport2_reactDom_client.default : __vite__cjsImport2_reactDom_client;
import "/resonant-landscapes/src/init.js";
import App from "/resonant-landscapes/src/App.tsx";
import "/resonant-landscapes/src/index.css";
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/ _jsxDEV(React.StrictMode, {
    children: /*#__PURE__*/ _jsxDEV(App, {}, void 0, false, {
        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/main.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this)
}, void 0, false, {
    fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/main.tsx",
    lineNumber: 8,
    columnNumber: 3
}, this));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1haW4udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFJlYWN0RE9NIGZyb20gXCJyZWFjdC1kb20vY2xpZW50XCI7XHJcbmltcG9ydCBcIi4vaW5pdFwiXHJcbmltcG9ydCBBcHAgZnJvbSBcIi4vQXBwXCI7XHJcbmltcG9ydCBcIi4vaW5kZXguY3NzXCI7XHJcblxyXG5SZWFjdERPTS5jcmVhdGVSb290KGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicm9vdFwiKSBhcyBIVE1MRWxlbWVudCkucmVuZGVyKFxyXG4gIDxSZWFjdC5TdHJpY3RNb2RlPlxyXG4gICAgPEFwcCAvPlxyXG4gIDwvUmVhY3QuU3RyaWN0TW9kZT5cclxuKTtcclxuIl0sIm5hbWVzIjpbIlJlYWN0IiwiUmVhY3RET00iLCJBcHAiLCJjcmVhdGVSb290IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInJlbmRlciIsIlN0cmljdE1vZGUiXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPQSxXQUFXLFFBQVE7QUFDMUIsT0FBT0MsY0FBYyxtQkFBbUI7QUFDeEMsT0FBTyxTQUFRO0FBQ2YsT0FBT0MsU0FBUyxRQUFRO0FBQ3hCLE9BQU8sY0FBYztBQUVyQkQsU0FBU0UsVUFBVSxDQUFDQyxTQUFTQyxjQUFjLENBQUMsU0FBd0JDLE1BQU0sZUFDeEUsUUFBQ04sTUFBTU8sVUFBVTtjQUNmLGNBQUEsUUFBQ0wifQ==