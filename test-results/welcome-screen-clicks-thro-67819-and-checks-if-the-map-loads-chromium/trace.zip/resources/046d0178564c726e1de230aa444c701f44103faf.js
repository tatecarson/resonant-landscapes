import {
  require_react
} from "/resonant-landscapes/node_modules/.vite/deps/chunk-RYHZ5DR2.js?v=88dff54b";
import "/resonant-landscapes/node_modules/.vite/deps/chunk-J32WSRGE.js?v=88dff54b";
export default require_react();
//# sourceMappingURL=react.js.map
