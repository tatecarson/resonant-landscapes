import { createHotContext as __vite__createHotContext } from "/resonant-landscapes/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/App.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/resonant-landscapes/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/resonant-landscapes/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88dff54b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/resonant-landscapes/node_modules/.vite/deps/react.js?v=88dff54b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react; const useState = __vite__cjsImport2_react["useState"];
import AudioContextProvider from "/resonant-landscapes/src/contexts/AudioContextProvider.tsx";
import OpenLayers from "/resonant-landscapes/src/components/OpenLayers.tsx";
import { ErrorBoundary } from "/resonant-landscapes/node_modules/.vite/deps/react-error-boundary.js?v=88dff54b";
import WelcomeModal from "/resonant-landscapes/src/components/WelcomeModal.tsx";
// import './App.css'
function App() {
    _s();
    let [isOpen, setIsOpen] = useState(true);
    return /*#__PURE__*/ _jsxDEV(ErrorBoundary, {
        fallback: /*#__PURE__*/ _jsxDEV("div", {
            children: "Error"
        }, void 0, false, {
            fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/App.tsx",
            lineNumber: 12,
            columnNumber: 30
        }, void 0),
        children: /*#__PURE__*/ _jsxDEV(AudioContextProvider, {
            children: [
                /*#__PURE__*/ _jsxDEV(WelcomeModal, {
                    isOpen: isOpen,
                    setIsOpen: setIsOpen
                }, void 0, false, {
                    fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/App.tsx",
                    lineNumber: 14,
                    columnNumber: 9
                }, this),
                !isOpen && /*#__PURE__*/ _jsxDEV(OpenLayers, {}, void 0, false, {
                    fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/App.tsx",
                    lineNumber: 15,
                    columnNumber: 21
                }, this)
            ]
        }, void 0, true, {
            fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/App.tsx",
            lineNumber: 13,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/App.tsx",
        lineNumber: 12,
        columnNumber: 5
    }, this);
}
_s(App, "mEi83NlPXQzy/XIDfTYWzOSvaHw=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/App.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/App.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBBdWRpb0NvbnRleHRQcm92aWRlciBmcm9tIFwiLi9jb250ZXh0cy9BdWRpb0NvbnRleHRQcm92aWRlclwiO1xyXG5pbXBvcnQgT3BlbkxheWVycyBmcm9tIFwiLi9jb21wb25lbnRzL09wZW5MYXllcnNcIjtcclxuaW1wb3J0IHsgRXJyb3JCb3VuZGFyeSB9IGZyb20gXCJyZWFjdC1lcnJvci1ib3VuZGFyeVwiO1xyXG5pbXBvcnQgV2VsY29tZU1vZGFsIGZyb20gXCIuL2NvbXBvbmVudHMvV2VsY29tZU1vZGFsXCI7XHJcbi8vIGltcG9ydCAnLi9BcHAuY3NzJ1xyXG5cclxuZnVuY3Rpb24gQXBwKCkge1xyXG4gIGxldCBbaXNPcGVuLCBzZXRJc09wZW5dID0gdXNlU3RhdGUodHJ1ZSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8RXJyb3JCb3VuZGFyeSBmYWxsYmFjaz17PGRpdj5FcnJvcjwvZGl2Pn0+XHJcbiAgICAgIDxBdWRpb0NvbnRleHRQcm92aWRlcj5cclxuICAgICAgICA8V2VsY29tZU1vZGFsIGlzT3Blbj17aXNPcGVufSBzZXRJc09wZW49e3NldElzT3Blbn0gLz5cclxuICAgICAgICB7IWlzT3BlbiAmJiA8T3BlbkxheWVycyAvPn1cclxuICAgICAgPC9BdWRpb0NvbnRleHRQcm92aWRlcj5cclxuICAgIDwvRXJyb3JCb3VuZGFyeT5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBcHA7XHJcbiJdLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwiQXVkaW9Db250ZXh0UHJvdmlkZXIiLCJPcGVuTGF5ZXJzIiwiRXJyb3JCb3VuZGFyeSIsIldlbGNvbWVNb2RhbCIsIkFwcCIsImlzT3BlbiIsInNldElzT3BlbiIsImZhbGxiYWNrIiwiZGl2Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUEsT0FBT0EsU0FBU0MsUUFBUSxRQUFRLFFBQVE7QUFDeEMsT0FBT0MsMEJBQTBCLGtDQUFrQztBQUNuRSxPQUFPQyxnQkFBZ0IsMEJBQTBCO0FBQ2pELFNBQVNDLGFBQWEsUUFBUSx1QkFBdUI7QUFDckQsT0FBT0Msa0JBQWtCLDRCQUE0QjtBQUNyRCxxQkFBcUI7QUFFckIsU0FBU0M7O0lBQ1AsSUFBSSxDQUFDQyxRQUFRQyxVQUFVLEdBQUdQLFNBQVM7SUFFbkMscUJBQ0UsUUFBQ0c7UUFBY0ssd0JBQVUsUUFBQ0M7c0JBQUk7Ozs7OztrQkFDNUIsY0FBQSxRQUFDUjs7OEJBQ0MsUUFBQ0c7b0JBQWFFLFFBQVFBO29CQUFRQyxXQUFXQTs7Ozs7O2dCQUN4QyxDQUFDRCx3QkFBVSxRQUFDSjs7Ozs7Ozs7Ozs7Ozs7OztBQUlyQjtHQVhTRztLQUFBQTtBQWFULGVBQWVBLElBQUkifQ==