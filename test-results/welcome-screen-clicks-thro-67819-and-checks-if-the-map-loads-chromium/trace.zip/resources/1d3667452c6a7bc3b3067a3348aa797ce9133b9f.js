import { createHotContext as __vite__createHotContext } from "/resonant-landscapes/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/OpenLayers.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/resonant-landscapes/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/resonant-landscapes/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=88dff54b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];
var _s = $RefreshSig$(), _s1 = $RefreshSig$();
import __vite__cjsImport2_react from "/resonant-landscapes/node_modules/.vite/deps/react.js?v=88dff54b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react; const useState = __vite__cjsImport2_react["useState"]; const useCallback = __vite__cjsImport2_react["useCallback"];
import { fromLonLat, toLonLat } from "/resonant-landscapes/node_modules/.vite/deps/ol_proj.js?v=88dff54b";
import { Point, LineString } from "/resonant-landscapes/node_modules/.vite/deps/ol_geom.js?v=88dff54b";
import Circle from "/resonant-landscapes/node_modules/.vite/deps/ol_geom_Circle.js?v=88dff54b";
import { RMap, ROSM, RLayerVector, RFeature, RGeolocation, RStyle, useOL, RPopup, RControl } from "/resonant-landscapes/node_modules/.vite/deps/rlayers.js?v=88dff54b";
import * as turf from "/resonant-landscapes/node_modules/.vite/deps/@turf_turf.js?v=88dff54b";
import ParkModal from "/resonant-landscapes/src/components/ParkModal.tsx";
import "/resonant-landscapes/node_modules/ol/ol.css";
import "/resonant-landscapes/src/components/layers.css";
import { useAudioContext } from "/resonant-landscapes/src/contexts/AudioContextProvider.tsx";
import HelpMenu from "/resonant-landscapes/src/components/HelpModal.tsx";
import scaledPoints from "/resonant-landscapes/src/js/scaledParks.js";
import marker from "/resonant-landscapes/src/assets/trees.png?import";
import locationIcon from "/resonant-landscapes/src/assets/geolocation_marker_heading.png?import";
import { ErrorBoundary } from "/resonant-landscapes/node_modules/.vite/deps/react-error-boundary.js?v=88dff54b";
// modulo for negative values
function mod(n) {
    return (n % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI);
}
function degToRad(deg) {
    return deg * Math.PI / 180;
}
function GeolocComp() {
    _s();
    const [pos, setPos] = useState(new Point(fromLonLat([
        0,
        0
    ]), 'XYZM'));
    const [accuracy, setAccuracy] = useState(null);
    const [deltaMean, setDeltaMean] = useState(500);
    const [previousM, setPreviousM] = useState(0);
    const [isOpen, setIsOpen] = useState(false);
    const [parkName, setParkName] = useState('');
    const [parkDistance, setParkDistance] = useState(0);
    const [currentParkLocation, setCurrentParkLocation] = useState([]);
    const [enableUserOrientation, setEanbleUserOrientation] = useState(false);
    const { resonanceAudioScene, stopSound } = useAudioContext();
    const positions = new LineString([], 'XYZM');
    // Low-level access to the OpenLayers API
    const { map } = useOL();
    const view = map?.getView();
    const maxDistance = 15; // meters
    function addPosition(position, heading, m, speed) {
        if (!position) return; // Guard clause if position is not provided
        const x = position[0];
        const y = position[1];
        const fCoords = positions.getCoordinates();
        const previous = fCoords[fCoords.length - 1];
        const prevHeading = previous && previous[2];
        let newHeading = heading;
        if (prevHeading !== undefined) {
            let headingDiff = newHeading - mod(prevHeading);
            if (Math.abs(headingDiff) > Math.PI) {
                const sign = headingDiff >= 0 ? 1 : -1;
                headingDiff = -sign * (2 * Math.PI - Math.abs(headingDiff));
            }
            newHeading = prevHeading + headingDiff;
        }
        positions.appendCoordinate([
            x,
            y,
            newHeading,
            m
        ]);
        positions.setCoordinates(positions.getCoordinates().slice(-20));
    }
    // recenters the view by putting the given coordinates at 3/4 from the top or
    // the screen
    function getCenterWithHeading(position, rotation, resolution) {
        const size = map?.getSize();
        if (!size) return position; // Return early if map size is not available
        const height = size[1];
        return [
            position[0] - Math.sin(rotation) * height * resolution * 1 / 4,
            position[1] + Math.cos(rotation) * height * resolution * 1 / 4
        ];
    }
    function updateView() {
        if (!view) return;
        // console.count('updateView() called');
        let m = Date.now() - deltaMean * 1.5;
        m = Math.max(m, previousM);
        setPreviousM(m);
        const c = positions.getCoordinateAtM(m, true);
        if (c) {
            view.setCenter(getCenterWithHeading([
                c[0],
                c[1]
            ], -c[2], view.getResolution() ?? 0));
            view.setRotation(-c[2]);
            setPos(c);
            const userLocation = turf.point(toLonLat([
                c[0],
                c[1]
            ]));
            scaledPoints.forEach((park)=>{
                // console.log("park", park.name, park.scaledCoords)
                const parkLocation = turf.point(park.scaledCoords);
                const distance = turf.distance(userLocation, parkLocation, {
                    units: 'meters'
                });
                if (distance < maxDistance && !isOpen) {
                    setIsOpen(true);
                    console.count('isOpen set to true');
                    setParkName(park.name);
                    setCurrentParkLocation(parkLocation);
                }
            });
            const currentParkDistance = turf.distance(currentParkLocation, userLocation, {
                units: 'meters'
            });
            if (currentParkDistance < maxDistance) {
                setParkDistance(currentParkDistance);
                if (resonanceAudioScene) {
                    console.log("Setting listener position to ", currentParkDistance, currentParkDistance, 0);
                    resonanceAudioScene.setListenerPosition(currentParkDistance, currentParkDistance, 0);
                }
                // minDistance
                if (currentParkDistance < 5) {
                    console.log("User is close to ", parkName);
                    setEanbleUserOrientation(true);
                } else {
                    setEanbleUserOrientation(false);
                }
            }
            // reset if the user walks away from the park center
            if (currentParkDistance > maxDistance && isOpen) {
                setIsOpen(false);
                stopSound();
            }
        }
    }
    function createParkFeature(scaledCoords, name, key) {
        // console.log("scaledCoords", scaledCoords, name)
        const pointGeometry = new Point(fromLonLat(scaledCoords));
        return /*#__PURE__*/ _jsxDEV(RFeature, {
            geometry: pointGeometry,
            children: [
                /*#__PURE__*/ _jsxDEV(RStyle.RStyle, {
                    children: /*#__PURE__*/ _jsxDEV(RStyle.RIcon, {
                        src: marker,
                        anchor: [
                            0.5,
                            0.8
                        ]
                    }, void 0, false, {
                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                        lineNumber: 164,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                    lineNumber: 162,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ _jsxDEV(RPopup, {
                    trigger: "click",
                    className: "example-overlay",
                    children: name
                }, void 0, false, {
                    fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                    lineNumber: 166,
                    columnNumber: 17
                }, this)
            ]
        }, key, true, {
            fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
            lineNumber: 161,
            columnNumber: 13
        }, this);
    }
    function createMaxDistanceFeature(scaledCoords, name, key) {
        const circleGeometry = new Circle(fromLonLat(scaledCoords), maxDistance);
        return /*#__PURE__*/ _jsxDEV(RFeature, {
            geometry: circleGeometry,
            children: /*#__PURE__*/ _jsxDEV(RStyle.RStyle, {
                children: [
                    /*#__PURE__*/ _jsxDEV(RStyle.RFill, {
                        color: "rgba(76, 175, 80, 0.2)"
                    }, void 0, false, {
                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                        lineNumber: 178,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ _jsxDEV(RStyle.RStroke, {
                        color: "green",
                        width: 2
                    }, void 0, false, {
                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                        lineNumber: 179,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                lineNumber: 177,
                columnNumber: 17
            }, this)
        }, key, false, {
            fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
            lineNumber: 176,
            columnNumber: 13
        }, this);
    }
    return /*#__PURE__*/ _jsxDEV("div", {
        children: [
            /*#__PURE__*/ _jsxDEV(RGeolocation, {
                tracking: true,
                trackingOptions: {
                    enableHighAccuracy: true
                },
                onChange: useCallback((e)=>{
                    const geoloc = e.target;
                    const position = geoloc.getPosition();
                    if (position) {
                        const [x, y] = position; // Destructure the position into x and y coordinates
                        setAccuracy(new LineString([
                            position
                        ]));
                        const m = Date.now();
                        // this line enables the geolocation feature 
                        addPosition([
                            x,
                            y
                        ], geoloc.getHeading() ?? 0, m, geoloc.getSpeed() ?? 0); // Pass [x, y] as the position
                        const coords = positions.getCoordinates();
                        const len = coords.length;
                        if (len >= 2) {
                            setDeltaMean((coords[len - 1][3] - coords[0][3]) / (len - 1));
                        }
                        updateView();
                    }
                }, [
                    positions,
                    map
                ] // Dependency array updated
                )
            }, void 0, false, {
                fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                lineNumber: 188,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ _jsxDEV(RLayerVector, {
                zIndex: 10,
                children: [
                    /*#__PURE__*/ _jsxDEV(RStyle.RStyle, {
                        children: [
                            /*#__PURE__*/ _jsxDEV(RStyle.RIcon, {
                                src: locationIcon,
                                anchor: [
                                    0.5,
                                    0.8
                                ]
                            }, void 0, false, {
                                fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                                lineNumber: 219,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ _jsxDEV(RStyle.RStroke, {
                                color: "#007bff",
                                width: 3
                            }, void 0, false, {
                                fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                                lineNumber: 220,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                        lineNumber: 218,
                        columnNumber: 17
                    }, this),
                    pos && /*#__PURE__*/ _jsxDEV(RFeature, {
                        geometry: new Point(pos)
                    }, void 0, false, {
                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                        lineNumber: 222,
                        columnNumber: 25
                    }, this),
                    accuracy && /*#__PURE__*/ _jsxDEV(RFeature, {
                        geometry: accuracy
                    }, void 0, false, {
                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                        lineNumber: 223,
                        columnNumber: 30
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                lineNumber: 217,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ _jsxDEV(RLayerVector, {
                zIndex: 9,
                children: scaledPoints.map((park, i)=>createParkFeature(park.scaledCoords, park.name, i))
            }, void 0, false, {
                fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                lineNumber: 226,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ _jsxDEV(RLayerVector, {
                zIndex: 10,
                children: scaledPoints.map((park, i)=>createMaxDistanceFeature(park.scaledCoords, park.name, i))
            }, void 0, false, {
                fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                lineNumber: 230,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ _jsxDEV(ErrorBoundary, {
                fallback: /*#__PURE__*/ _jsxDEV("div", {
                    children: "Error"
                }, void 0, false, {
                    fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                    lineNumber: 233,
                    columnNumber: 38
                }, void 0),
                children: isOpen && /*#__PURE__*/ _jsxDEV(ParkModal, {
                    isOpen: isOpen,
                    setIsOpen: setIsOpen,
                    parkName: parkName,
                    parkDistance: parkDistance,
                    userOrientation: enableUserOrientation
                }, void 0, false, {
                    fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                    lineNumber: 234,
                    columnNumber: 28
                }, this)
            }, void 0, false, {
                fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                lineNumber: 233,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
        lineNumber: 187,
        columnNumber: 9
    }, this);
}
_s(GeolocComp, "j1w6QSoSXlll6XpnQVd9gJMT8No=", false, function() {
    return [
        useAudioContext,
        useOL
    ];
});
_c = GeolocComp;
export default function Geolocation() {
    _s1();
    const [helpIsOpen, setHelpIsOpen] = useState(false);
    return /*#__PURE__*/ _jsxDEV(_Fragment, {
        children: /*#__PURE__*/ _jsxDEV(RMap, {
            className: "map",
            initial: {
                center: fromLonLat([
                    0,
                    0
                ]),
                zoom: 19
            },
            children: [
                /*#__PURE__*/ _jsxDEV(RControl.RCustom, {
                    className: "example-control",
                    children: /*#__PURE__*/ _jsxDEV("button", {
                        onClick: ()=>setHelpIsOpen(true),
                        children: "?"
                    }, void 0, false, {
                        fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                        lineNumber: 254,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                    lineNumber: 253,
                    columnNumber: 17
                }, this),
                helpIsOpen && /*#__PURE__*/ _jsxDEV(HelpMenu, {
                    isOpen: helpIsOpen,
                    setIsOpen: setHelpIsOpen
                }, void 0, false, {
                    fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                    lineNumber: 258,
                    columnNumber: 32
                }, this),
                /*#__PURE__*/ _jsxDEV(ROSM, {}, void 0, false, {
                    fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                    lineNumber: 259,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ _jsxDEV(GeolocComp, {}, void 0, false, {
                    fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
                    lineNumber: 260,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx",
            lineNumber: 249,
            columnNumber: 13
        }, this)
    }, void 0, false);
}
_s1(Geolocation, "cdJAMlBRtthW5kiV36WVWcDU4s0=");
_c1 = Geolocation;
var _c, _c1;
$RefreshReg$(_c, "GeolocComp");
$RefreshReg$(_c1, "Geolocation");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/tatecarson/websites/sd-state-parks/js-ambisonics-react/src/components/OpenLayers.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIk9wZW5MYXllcnMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VDYWxsYmFjaywgbWVtbywgdXNlUmVmLCB1c2VDb250ZXh0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBmcm9tTG9uTGF0LCB0b0xvbkxhdCB9IGZyb20gXCJvbC9wcm9qXCI7XG5pbXBvcnQgeyBHZW9tZXRyeSwgUG9pbnQsIExpbmVTdHJpbmcgfSBmcm9tIFwib2wvZ2VvbVwiO1xuaW1wb3J0IENpcmNsZSBmcm9tICdvbC9nZW9tL0NpcmNsZSc7XG5pbXBvcnQgeyBHZW9sb2NhdGlvbiBhcyBPTEdlb0xvYyB9IGZyb20gXCJvbFwiO1xuaW1wb3J0IHtcbiAgICBSTWFwLFxuICAgIFJPU00sXG4gICAgUkxheWVyVmVjdG9yLFxuICAgIFJGZWF0dXJlLFxuICAgIFJHZW9sb2NhdGlvbixcbiAgICBSU3R5bGUsXG4gICAgUk92ZXJsYXksXG4gICAgdXNlT0wsXG4gICAgUlBvcHVwLFxuICAgIFJDb250cm9sXG59IGZyb20gXCJybGF5ZXJzXCI7XG5pbXBvcnQgKiBhcyB0dXJmIGZyb20gJ0B0dXJmL3R1cmYnO1xuXG5pbXBvcnQgUGFya01vZGFsIGZyb20gXCIuL1BhcmtNb2RhbFwiO1xuaW1wb3J0IFwib2wvb2wuY3NzXCI7XG5pbXBvcnQgJy4vbGF5ZXJzLmNzcydcblxuaW1wb3J0IHsgdXNlQXVkaW9Db250ZXh0IH0gZnJvbSBcIi4uL2NvbnRleHRzL0F1ZGlvQ29udGV4dFByb3ZpZGVyXCI7XG5pbXBvcnQgSGVscE1lbnUgZnJvbSBcIi4vSGVscE1vZGFsXCI7XG5cbmltcG9ydCBzY2FsZWRQb2ludHMgZnJvbSBcIi4uL2pzL3NjYWxlZFBhcmtzXCI7XG5pbXBvcnQgbWFya2VyIGZyb20gJy4uL2Fzc2V0cy90cmVlcy5wbmcnXG5pbXBvcnQgbG9jYXRpb25JY29uIGZyb20gXCIuLi9hc3NldHMvZ2VvbG9jYXRpb25fbWFya2VyX2hlYWRpbmcucG5nXCI7XG5pbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSBcInJlYWN0LWVycm9yLWJvdW5kYXJ5XCI7XG5cbi8vIG1vZHVsbyBmb3IgbmVnYXRpdmUgdmFsdWVzXG5mdW5jdGlvbiBtb2QobjogbnVtYmVyKSB7XG4gICAgcmV0dXJuICgobiAlICgyICogTWF0aC5QSSkpICsgMiAqIE1hdGguUEkpICUgKDIgKiBNYXRoLlBJKTtcbn1cblxuZnVuY3Rpb24gZGVnVG9SYWQoZGVnOiBudW1iZXIpIHtcbiAgICByZXR1cm4gKGRlZyAqIE1hdGguUEkpIC8gMTgwO1xufVxuXG5mdW5jdGlvbiBHZW9sb2NDb21wKCk6IEpTWC5FbGVtZW50IHtcblxuICAgIGNvbnN0IFtwb3MsIHNldFBvc10gPSB1c2VTdGF0ZShuZXcgUG9pbnQoZnJvbUxvbkxhdChbMCwgMF0pLCAnWFlaTScpKTtcbiAgICBjb25zdCBbYWNjdXJhY3ksIHNldEFjY3VyYWN5XSA9IHVzZVN0YXRlPExpbmVTdHJpbmcgfCBudWxsPihudWxsKTtcbiAgICBjb25zdCBbZGVsdGFNZWFuLCBzZXREZWx0YU1lYW5dID0gdXNlU3RhdGU8bnVtYmVyPig1MDApO1xuICAgIGNvbnN0IFtwcmV2aW91c00sIHNldFByZXZpb3VzTV0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuXG4gICAgY29uc3QgW2lzT3Blbiwgc2V0SXNPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKVxuICAgIGNvbnN0IFtwYXJrTmFtZSwgc2V0UGFya05hbWVdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG4gICAgY29uc3QgW3BhcmtEaXN0YW5jZSwgc2V0UGFya0Rpc3RhbmNlXSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7XG4gICAgY29uc3QgW2N1cnJlbnRQYXJrTG9jYXRpb24sIHNldEN1cnJlbnRQYXJrTG9jYXRpb25dID0gdXNlU3RhdGUoW10pO1xuICAgIGNvbnN0IFtlbmFibGVVc2VyT3JpZW50YXRpb24sIHNldEVhbmJsZVVzZXJPcmllbnRhdGlvbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICBjb25zdCB7IHJlc29uYW5jZUF1ZGlvU2NlbmUsIHN0b3BTb3VuZCB9ID0gdXNlQXVkaW9Db250ZXh0KCk7XG5cbiAgICBjb25zdCBwb3NpdGlvbnMgPSBuZXcgTGluZVN0cmluZyhbXSwgJ1hZWk0nKTtcblxuICAgIC8vIExvdy1sZXZlbCBhY2Nlc3MgdG8gdGhlIE9wZW5MYXllcnMgQVBJXG4gICAgY29uc3QgeyBtYXAgfSA9IHVzZU9MKCk7XG5cbiAgICBjb25zdCB2aWV3ID0gbWFwPy5nZXRWaWV3KCk7XG5cbiAgICBjb25zdCBtYXhEaXN0YW5jZSA9IDE1OyAvLyBtZXRlcnNcblxuICAgIGZ1bmN0aW9uIGFkZFBvc2l0aW9uKHBvc2l0aW9uOiBbbnVtYmVyLCBudW1iZXJdLCBoZWFkaW5nOiBudW1iZXIsIG06IG51bWJlciwgc3BlZWQ6IG51bWJlcikge1xuICAgICAgICBpZiAoIXBvc2l0aW9uKSByZXR1cm47IC8vIEd1YXJkIGNsYXVzZSBpZiBwb3NpdGlvbiBpcyBub3QgcHJvdmlkZWRcblxuICAgICAgICBjb25zdCB4ID0gcG9zaXRpb25bMF07XG4gICAgICAgIGNvbnN0IHkgPSBwb3NpdGlvblsxXTtcbiAgICAgICAgY29uc3QgZkNvb3JkcyA9IHBvc2l0aW9ucy5nZXRDb29yZGluYXRlcygpO1xuICAgICAgICBjb25zdCBwcmV2aW91cyA9IGZDb29yZHNbZkNvb3Jkcy5sZW5ndGggLSAxXTtcbiAgICAgICAgY29uc3QgcHJldkhlYWRpbmcgPSBwcmV2aW91cyAmJiBwcmV2aW91c1syXTtcbiAgICAgICAgbGV0IG5ld0hlYWRpbmcgPSBoZWFkaW5nO1xuICAgICAgICBpZiAocHJldkhlYWRpbmcgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgbGV0IGhlYWRpbmdEaWZmID0gbmV3SGVhZGluZyAtIG1vZChwcmV2SGVhZGluZyk7XG5cbiAgICAgICAgICAgIGlmIChNYXRoLmFicyhoZWFkaW5nRGlmZikgPiBNYXRoLlBJKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgc2lnbiA9IGhlYWRpbmdEaWZmID49IDAgPyAxIDogLTE7XG4gICAgICAgICAgICAgICAgaGVhZGluZ0RpZmYgPSAtc2lnbiAqICgyICogTWF0aC5QSSAtIE1hdGguYWJzKGhlYWRpbmdEaWZmKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBuZXdIZWFkaW5nID0gcHJldkhlYWRpbmcgKyBoZWFkaW5nRGlmZjtcbiAgICAgICAgfVxuICAgICAgICBwb3NpdGlvbnMuYXBwZW5kQ29vcmRpbmF0ZShbeCwgeSwgbmV3SGVhZGluZywgbV0pO1xuXG4gICAgICAgIHBvc2l0aW9ucy5zZXRDb29yZGluYXRlcyhwb3NpdGlvbnMuZ2V0Q29vcmRpbmF0ZXMoKS5zbGljZSgtMjApKTtcbiAgICB9XG5cbiAgICAvLyByZWNlbnRlcnMgdGhlIHZpZXcgYnkgcHV0dGluZyB0aGUgZ2l2ZW4gY29vcmRpbmF0ZXMgYXQgMy80IGZyb20gdGhlIHRvcCBvclxuICAgIC8vIHRoZSBzY3JlZW5cbiAgICBmdW5jdGlvbiBnZXRDZW50ZXJXaXRoSGVhZGluZyhwb3NpdGlvbjogW251bWJlciwgbnVtYmVyXSwgcm90YXRpb246IG51bWJlciwgcmVzb2x1dGlvbjogbnVtYmVyKSB7XG4gICAgICAgIGNvbnN0IHNpemUgPSBtYXA/LmdldFNpemUoKTtcbiAgICAgICAgaWYgKCFzaXplKSByZXR1cm4gcG9zaXRpb247IC8vIFJldHVybiBlYXJseSBpZiBtYXAgc2l6ZSBpcyBub3QgYXZhaWxhYmxlXG5cbiAgICAgICAgY29uc3QgaGVpZ2h0ID0gc2l6ZVsxXTtcblxuICAgICAgICByZXR1cm4gW1xuICAgICAgICAgICAgcG9zaXRpb25bMF0gLSAoTWF0aC5zaW4ocm90YXRpb24pICogaGVpZ2h0ICogcmVzb2x1dGlvbiAqIDEpIC8gNCxcbiAgICAgICAgICAgIHBvc2l0aW9uWzFdICsgKE1hdGguY29zKHJvdGF0aW9uKSAqIGhlaWdodCAqIHJlc29sdXRpb24gKiAxKSAvIDQsXG4gICAgICAgIF07XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gdXBkYXRlVmlldygpIHtcbiAgICAgICAgaWYgKCF2aWV3KSByZXR1cm47XG5cbiAgICAgICAgLy8gY29uc29sZS5jb3VudCgndXBkYXRlVmlldygpIGNhbGxlZCcpO1xuICAgICAgICBsZXQgbSA9IERhdGUubm93KCkgLSBkZWx0YU1lYW4gKiAxLjU7XG4gICAgICAgIG0gPSBNYXRoLm1heChtLCBwcmV2aW91c00pO1xuICAgICAgICBzZXRQcmV2aW91c00obSk7XG5cbiAgICAgICAgY29uc3QgYyA9IHBvc2l0aW9ucy5nZXRDb29yZGluYXRlQXRNKG0sIHRydWUpO1xuXG4gICAgICAgIGlmIChjKSB7XG4gICAgICAgICAgICB2aWV3LnNldENlbnRlcihnZXRDZW50ZXJXaXRoSGVhZGluZyhbY1swXSwgY1sxXV0sIC1jWzJdLCB2aWV3LmdldFJlc29sdXRpb24oKSA/PyAwKSk7XG4gICAgICAgICAgICB2aWV3LnNldFJvdGF0aW9uKC1jWzJdKTtcbiAgICAgICAgICAgIHNldFBvcyhjKTtcblxuICAgICAgICAgICAgY29uc3QgdXNlckxvY2F0aW9uID0gdHVyZi5wb2ludCh0b0xvbkxhdChbY1swXSwgY1sxXV0pKTtcbiAgICAgICAgICAgIHNjYWxlZFBvaW50cy5mb3JFYWNoKHBhcmsgPT4ge1xuICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwicGFya1wiLCBwYXJrLm5hbWUsIHBhcmsuc2NhbGVkQ29vcmRzKVxuICAgICAgICAgICAgICAgIGNvbnN0IHBhcmtMb2NhdGlvbiA9IHR1cmYucG9pbnQocGFyay5zY2FsZWRDb29yZHMpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGRpc3RhbmNlID0gdHVyZi5kaXN0YW5jZSh1c2VyTG9jYXRpb24sIHBhcmtMb2NhdGlvbiwgeyB1bml0czogJ21ldGVycycgfSk7XG4gICAgICAgICAgICAgICAgaWYgKGRpc3RhbmNlIDwgbWF4RGlzdGFuY2UgJiYgIWlzT3Blbikge1xuICAgICAgICAgICAgICAgICAgICBzZXRJc09wZW4odHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuY291bnQoJ2lzT3BlbiBzZXQgdG8gdHJ1ZScpO1xuICAgICAgICAgICAgICAgICAgICBzZXRQYXJrTmFtZShwYXJrLm5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBzZXRDdXJyZW50UGFya0xvY2F0aW9uKHBhcmtMb2NhdGlvbik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRQYXJrRGlzdGFuY2UgPSB0dXJmLmRpc3RhbmNlKGN1cnJlbnRQYXJrTG9jYXRpb24sIHVzZXJMb2NhdGlvbiwgeyB1bml0czogJ21ldGVycycgfSk7XG5cbiAgICAgICAgICAgIGlmIChjdXJyZW50UGFya0Rpc3RhbmNlIDwgbWF4RGlzdGFuY2UpIHtcbiAgICAgICAgICAgICAgICBzZXRQYXJrRGlzdGFuY2UoY3VycmVudFBhcmtEaXN0YW5jZSk7XG5cbiAgICAgICAgICAgICAgICBpZiAocmVzb25hbmNlQXVkaW9TY2VuZSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlNldHRpbmcgbGlzdGVuZXIgcG9zaXRpb24gdG8gXCIsIGN1cnJlbnRQYXJrRGlzdGFuY2UsIGN1cnJlbnRQYXJrRGlzdGFuY2UsIDApXG4gICAgICAgICAgICAgICAgICAgIHJlc29uYW5jZUF1ZGlvU2NlbmUuc2V0TGlzdGVuZXJQb3NpdGlvbihjdXJyZW50UGFya0Rpc3RhbmNlLCBjdXJyZW50UGFya0Rpc3RhbmNlLCAwKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAvLyBtaW5EaXN0YW5jZVxuICAgICAgICAgICAgICAgIGlmIChjdXJyZW50UGFya0Rpc3RhbmNlIDwgNSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlVzZXIgaXMgY2xvc2UgdG8gXCIsIHBhcmtOYW1lKVxuICAgICAgICAgICAgICAgICAgICBzZXRFYW5ibGVVc2VyT3JpZW50YXRpb24odHJ1ZSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0RWFuYmxlVXNlck9yaWVudGF0aW9uKGZhbHNlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyByZXNldCBpZiB0aGUgdXNlciB3YWxrcyBhd2F5IGZyb20gdGhlIHBhcmsgY2VudGVyXG4gICAgICAgICAgICBpZiAoY3VycmVudFBhcmtEaXN0YW5jZSA+IG1heERpc3RhbmNlICYmIGlzT3Blbikge1xuICAgICAgICAgICAgICAgIHNldElzT3BlbihmYWxzZSk7XG4gICAgICAgICAgICAgICAgc3RvcFNvdW5kKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cblxuICAgIGZ1bmN0aW9uIGNyZWF0ZVBhcmtGZWF0dXJlKHNjYWxlZENvb3JkczogW251bWJlciwgbnVtYmVyXSwgbmFtZTogc3RyaW5nLCBrZXk6IG51bWJlcikge1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhcInNjYWxlZENvb3Jkc1wiLCBzY2FsZWRDb29yZHMsIG5hbWUpXG4gICAgICAgIGNvbnN0IHBvaW50R2VvbWV0cnkgPSBuZXcgUG9pbnQoZnJvbUxvbkxhdChzY2FsZWRDb29yZHMpKTtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxSRmVhdHVyZSBnZW9tZXRyeT17cG9pbnRHZW9tZXRyeX0ga2V5PXtrZXl9PlxuICAgICAgICAgICAgICAgIDxSU3R5bGUuUlN0eWxlPlxuXG4gICAgICAgICAgICAgICAgICAgIDxSU3R5bGUuUkljb24gc3JjPXttYXJrZXJ9IGFuY2hvcj17WzAuNSwgMC44XX0gLz5cbiAgICAgICAgICAgICAgICA8L1JTdHlsZS5SU3R5bGU+XG4gICAgICAgICAgICAgICAgPFJQb3B1cCB0cmlnZ2VyPXtcImNsaWNrXCJ9IGNsYXNzTmFtZT1cImV4YW1wbGUtb3ZlcmxheVwiPlxuICAgICAgICAgICAgICAgICAgICB7bmFtZX1cbiAgICAgICAgICAgICAgICA8L1JQb3B1cD5cbiAgICAgICAgICAgIDwvUkZlYXR1cmU+XG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gY3JlYXRlTWF4RGlzdGFuY2VGZWF0dXJlKHNjYWxlZENvb3JkczogW251bWJlciwgbnVtYmVyXSwgbmFtZTogc3RyaW5nLCBrZXk6IG51bWJlcikge1xuICAgICAgICBjb25zdCBjaXJjbGVHZW9tZXRyeSA9IG5ldyBDaXJjbGUoZnJvbUxvbkxhdChzY2FsZWRDb29yZHMpLCBtYXhEaXN0YW5jZSk7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8UkZlYXR1cmUgZ2VvbWV0cnk9e2NpcmNsZUdlb21ldHJ5fSBrZXk9e2tleX0+XG4gICAgICAgICAgICAgICAgPFJTdHlsZS5SU3R5bGU+XG4gICAgICAgICAgICAgICAgICAgIDxSU3R5bGUuUkZpbGwgY29sb3I9e1wicmdiYSg3NiwgMTc1LCA4MCwgMC4yKVwifSAvPlxuICAgICAgICAgICAgICAgICAgICA8UlN0eWxlLlJTdHJva2UgY29sb3I9e1wiZ3JlZW5cIn0gd2lkdGg9ezJ9IC8+XG4gICAgICAgICAgICAgICAgPC9SU3R5bGUuUlN0eWxlPlxuICAgICAgICAgICAgPC9SRmVhdHVyZT5cbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICByZXR1cm4gKFxuXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8Ukdlb2xvY2F0aW9uXG4gICAgICAgICAgICAgICAgdHJhY2tpbmc9e3RydWV9XG4gICAgICAgICAgICAgICAgdHJhY2tpbmdPcHRpb25zPXt7IGVuYWJsZUhpZ2hBY2N1cmFjeTogdHJ1ZSB9fVxuXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e3VzZUNhbGxiYWNrKFxuICAgICAgICAgICAgICAgICAgICAoZTogeyB0YXJnZXQ6IE9MR2VvTG9jOyB9KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBnZW9sb2MgPSBlLnRhcmdldCBhcyBPTEdlb0xvYztcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHBvc2l0aW9uID0gZ2VvbG9jLmdldFBvc2l0aW9uKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocG9zaXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBbeCwgeV0gPSBwb3NpdGlvbjsgLy8gRGVzdHJ1Y3R1cmUgdGhlIHBvc2l0aW9uIGludG8geCBhbmQgeSBjb29yZGluYXRlc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEFjY3VyYWN5KG5ldyBMaW5lU3RyaW5nKFtwb3NpdGlvbl0pKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBtID0gRGF0ZS5ub3coKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB0aGlzIGxpbmUgZW5hYmxlcyB0aGUgZ2VvbG9jYXRpb24gZmVhdHVyZSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRQb3NpdGlvbihbeCwgeV0sIGdlb2xvYy5nZXRIZWFkaW5nKCkgPz8gMCwgbSwgZ2VvbG9jLmdldFNwZWVkKCkgPz8gMCk7IC8vIFBhc3MgW3gsIHldIGFzIHRoZSBwb3NpdGlvblxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY29vcmRzID0gcG9zaXRpb25zLmdldENvb3JkaW5hdGVzKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbGVuID0gY29vcmRzLmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobGVuID49IDIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RGVsdGFNZWFuKChjb29yZHNbbGVuIC0gMV1bM10gLSBjb29yZHNbMF1bM10pIC8gKGxlbiAtIDEpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVWaWV3KCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgW3Bvc2l0aW9ucywgbWFwXSAvLyBEZXBlbmRlbmN5IGFycmF5IHVwZGF0ZWRcbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgPFJMYXllclZlY3RvciB6SW5kZXg9ezEwfT5cbiAgICAgICAgICAgICAgICA8UlN0eWxlLlJTdHlsZT5cbiAgICAgICAgICAgICAgICAgICAgPFJTdHlsZS5SSWNvbiBzcmM9e2xvY2F0aW9uSWNvbn0gYW5jaG9yPXtbMC41LCAwLjhdfSAvPlxuICAgICAgICAgICAgICAgICAgICA8UlN0eWxlLlJTdHJva2UgY29sb3I9e1wiIzAwN2JmZlwifSB3aWR0aD17M30gLz5cbiAgICAgICAgICAgICAgICA8L1JTdHlsZS5SU3R5bGU+XG4gICAgICAgICAgICAgICAge3BvcyAmJiA8UkZlYXR1cmUgZ2VvbWV0cnk9e25ldyBQb2ludChwb3MpfT48L1JGZWF0dXJlPn1cbiAgICAgICAgICAgICAgICB7YWNjdXJhY3kgJiYgPFJGZWF0dXJlIGdlb21ldHJ5PXthY2N1cmFjeX0+PC9SRmVhdHVyZT59XG4gICAgICAgICAgICA8L1JMYXllclZlY3Rvcj5cblxuICAgICAgICAgICAgPFJMYXllclZlY3RvciB6SW5kZXg9ezl9PlxuICAgICAgICAgICAgICAgIHtzY2FsZWRQb2ludHMubWFwKChwYXJrLCBpKSA9PiBjcmVhdGVQYXJrRmVhdHVyZShwYXJrLnNjYWxlZENvb3JkcywgcGFyay5uYW1lLCBpKSl9XG4gICAgICAgICAgICA8L1JMYXllclZlY3Rvcj5cblxuICAgICAgICAgICAgPFJMYXllclZlY3RvciB6SW5kZXg9ezEwfT5cbiAgICAgICAgICAgICAgICB7c2NhbGVkUG9pbnRzLm1hcCgocGFyaywgaSkgPT4gY3JlYXRlTWF4RGlzdGFuY2VGZWF0dXJlKHBhcmsuc2NhbGVkQ29vcmRzLCBwYXJrLm5hbWUsIGkpKX1cbiAgICAgICAgICAgIDwvUkxheWVyVmVjdG9yPlxuICAgICAgICAgICAgPEVycm9yQm91bmRhcnkgZmFsbGJhY2s9ezxkaXY+RXJyb3I8L2Rpdj59PlxuICAgICAgICAgICAgICAgIHtpc09wZW4gJiYgPFBhcmtNb2RhbCBpc09wZW49e2lzT3Blbn0gc2V0SXNPcGVuPXtzZXRJc09wZW59IHBhcmtOYW1lPXtwYXJrTmFtZX0gcGFya0Rpc3RhbmNlPXtwYXJrRGlzdGFuY2V9IHVzZXJPcmllbnRhdGlvbj17ZW5hYmxlVXNlck9yaWVudGF0aW9ufSAvPn1cbiAgICAgICAgICAgIDwvRXJyb3JCb3VuZGFyeT5cblxuICAgICAgICA8L2Rpdj5cblxuICAgICk7XG59XG5cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gR2VvbG9jYXRpb24oKTogSlNYLkVsZW1lbnQge1xuICAgIGNvbnN0IFtoZWxwSXNPcGVuLCBzZXRIZWxwSXNPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKVxuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPD5cblxuICAgICAgICAgICAgPFJNYXBcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYXBcIlxuICAgICAgICAgICAgICAgIGluaXRpYWw9e3sgY2VudGVyOiBmcm9tTG9uTGF0KFswLCAwXSksIHpvb206IDE5IH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFJDb250cm9sLlJDdXN0b20gY2xhc3NOYW1lPVwiZXhhbXBsZS1jb250cm9sXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0SGVscElzT3Blbih0cnVlKX0+XG4gICAgICAgICAgICAgICAgICAgICAgICA/XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvUkNvbnRyb2wuUkN1c3RvbT5cbiAgICAgICAgICAgICAgICB7aGVscElzT3BlbiAmJiA8SGVscE1lbnUgaXNPcGVuPXtoZWxwSXNPcGVufSBzZXRJc09wZW49e3NldEhlbHBJc09wZW59IC8+fVxuICAgICAgICAgICAgICAgIDxST1NNIC8+XG4gICAgICAgICAgICAgICAgPEdlb2xvY0NvbXAgLz5cblxuICAgICAgICAgICAgPC9STWFwPlxuXG4gICAgICAgIDwvPlxuICAgICk7XG59XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsInVzZUNhbGxiYWNrIiwiZnJvbUxvbkxhdCIsInRvTG9uTGF0IiwiUG9pbnQiLCJMaW5lU3RyaW5nIiwiQ2lyY2xlIiwiUk1hcCIsIlJPU00iLCJSTGF5ZXJWZWN0b3IiLCJSRmVhdHVyZSIsIlJHZW9sb2NhdGlvbiIsIlJTdHlsZSIsInVzZU9MIiwiUlBvcHVwIiwiUkNvbnRyb2wiLCJ0dXJmIiwiUGFya01vZGFsIiwidXNlQXVkaW9Db250ZXh0IiwiSGVscE1lbnUiLCJzY2FsZWRQb2ludHMiLCJtYXJrZXIiLCJsb2NhdGlvbkljb24iLCJFcnJvckJvdW5kYXJ5IiwibW9kIiwibiIsIk1hdGgiLCJQSSIsImRlZ1RvUmFkIiwiZGVnIiwiR2VvbG9jQ29tcCIsInBvcyIsInNldFBvcyIsImFjY3VyYWN5Iiwic2V0QWNjdXJhY3kiLCJkZWx0YU1lYW4iLCJzZXREZWx0YU1lYW4iLCJwcmV2aW91c00iLCJzZXRQcmV2aW91c00iLCJpc09wZW4iLCJzZXRJc09wZW4iLCJwYXJrTmFtZSIsInNldFBhcmtOYW1lIiwicGFya0Rpc3RhbmNlIiwic2V0UGFya0Rpc3RhbmNlIiwiY3VycmVudFBhcmtMb2NhdGlvbiIsInNldEN1cnJlbnRQYXJrTG9jYXRpb24iLCJlbmFibGVVc2VyT3JpZW50YXRpb24iLCJzZXRFYW5ibGVVc2VyT3JpZW50YXRpb24iLCJyZXNvbmFuY2VBdWRpb1NjZW5lIiwic3RvcFNvdW5kIiwicG9zaXRpb25zIiwibWFwIiwidmlldyIsImdldFZpZXciLCJtYXhEaXN0YW5jZSIsImFkZFBvc2l0aW9uIiwicG9zaXRpb24iLCJoZWFkaW5nIiwibSIsInNwZWVkIiwieCIsInkiLCJmQ29vcmRzIiwiZ2V0Q29vcmRpbmF0ZXMiLCJwcmV2aW91cyIsImxlbmd0aCIsInByZXZIZWFkaW5nIiwibmV3SGVhZGluZyIsInVuZGVmaW5lZCIsImhlYWRpbmdEaWZmIiwiYWJzIiwic2lnbiIsImFwcGVuZENvb3JkaW5hdGUiLCJzZXRDb29yZGluYXRlcyIsInNsaWNlIiwiZ2V0Q2VudGVyV2l0aEhlYWRpbmciLCJyb3RhdGlvbiIsInJlc29sdXRpb24iLCJzaXplIiwiZ2V0U2l6ZSIsImhlaWdodCIsInNpbiIsImNvcyIsInVwZGF0ZVZpZXciLCJEYXRlIiwibm93IiwibWF4IiwiYyIsImdldENvb3JkaW5hdGVBdE0iLCJzZXRDZW50ZXIiLCJnZXRSZXNvbHV0aW9uIiwic2V0Um90YXRpb24iLCJ1c2VyTG9jYXRpb24iLCJwb2ludCIsImZvckVhY2giLCJwYXJrIiwicGFya0xvY2F0aW9uIiwic2NhbGVkQ29vcmRzIiwiZGlzdGFuY2UiLCJ1bml0cyIsImNvbnNvbGUiLCJjb3VudCIsIm5hbWUiLCJjdXJyZW50UGFya0Rpc3RhbmNlIiwibG9nIiwic2V0TGlzdGVuZXJQb3NpdGlvbiIsImNyZWF0ZVBhcmtGZWF0dXJlIiwia2V5IiwicG9pbnRHZW9tZXRyeSIsImdlb21ldHJ5IiwiUkljb24iLCJzcmMiLCJhbmNob3IiLCJ0cmlnZ2VyIiwiY2xhc3NOYW1lIiwiY3JlYXRlTWF4RGlzdGFuY2VGZWF0dXJlIiwiY2lyY2xlR2VvbWV0cnkiLCJSRmlsbCIsImNvbG9yIiwiUlN0cm9rZSIsIndpZHRoIiwiZGl2IiwidHJhY2tpbmciLCJ0cmFja2luZ09wdGlvbnMiLCJlbmFibGVIaWdoQWNjdXJhY3kiLCJvbkNoYW5nZSIsImUiLCJnZW9sb2MiLCJ0YXJnZXQiLCJnZXRQb3NpdGlvbiIsImdldEhlYWRpbmciLCJnZXRTcGVlZCIsImNvb3JkcyIsImxlbiIsInpJbmRleCIsImkiLCJmYWxsYmFjayIsInVzZXJPcmllbnRhdGlvbiIsIkdlb2xvY2F0aW9uIiwiaGVscElzT3BlbiIsInNldEhlbHBJc09wZW4iLCJpbml0aWFsIiwiY2VudGVyIiwiem9vbSIsIlJDdXN0b20iLCJidXR0b24iLCJvbkNsaWNrIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUEsT0FBT0EsU0FBU0MsUUFBUSxFQUFhQyxXQUFXLFFBQWtDLFFBQVE7QUFDMUYsU0FBU0MsVUFBVSxFQUFFQyxRQUFRLFFBQVEsVUFBVTtBQUMvQyxTQUFtQkMsS0FBSyxFQUFFQyxVQUFVLFFBQVEsVUFBVTtBQUN0RCxPQUFPQyxZQUFZLGlCQUFpQjtBQUVwQyxTQUNJQyxJQUFJLEVBQ0pDLElBQUksRUFDSkMsWUFBWSxFQUNaQyxRQUFRLEVBQ1JDLFlBQVksRUFDWkMsTUFBTSxFQUVOQyxLQUFLLEVBQ0xDLE1BQU0sRUFDTkMsUUFBUSxRQUNMLFVBQVU7QUFDakIsWUFBWUMsVUFBVSxhQUFhO0FBRW5DLE9BQU9DLGVBQWUsY0FBYztBQUNwQyxPQUFPLFlBQVk7QUFDbkIsT0FBTyxlQUFjO0FBRXJCLFNBQVNDLGVBQWUsUUFBUSxtQ0FBbUM7QUFDbkUsT0FBT0MsY0FBYyxjQUFjO0FBRW5DLE9BQU9DLGtCQUFrQixvQkFBb0I7QUFDN0MsT0FBT0MsWUFBWSxzQkFBcUI7QUFDeEMsT0FBT0Msa0JBQWtCLDJDQUEyQztBQUNwRSxTQUFTQyxhQUFhLFFBQVEsdUJBQXVCO0FBRXJELDZCQUE2QjtBQUM3QixTQUFTQyxJQUFJQyxDQUFTO0lBQ2xCLE9BQU8sQUFBQyxDQUFBLEFBQUNBLElBQUssQ0FBQSxJQUFJQyxLQUFLQyxFQUFFLEFBQUQsSUFBTSxJQUFJRCxLQUFLQyxFQUFFLEFBQUQsSUFBTSxDQUFBLElBQUlELEtBQUtDLEVBQUUsQUFBRDtBQUM1RDtBQUVBLFNBQVNDLFNBQVNDLEdBQVc7SUFDekIsT0FBTyxBQUFDQSxNQUFNSCxLQUFLQyxFQUFFLEdBQUk7QUFDN0I7QUFFQSxTQUFTRzs7SUFFTCxNQUFNLENBQUNDLEtBQUtDLE9BQU8sR0FBR2hDLFNBQVMsSUFBSUksTUFBTUYsV0FBVztRQUFDO1FBQUc7S0FBRSxHQUFHO0lBQzdELE1BQU0sQ0FBQytCLFVBQVVDLFlBQVksR0FBR2xDLFNBQTRCO0lBQzVELE1BQU0sQ0FBQ21DLFdBQVdDLGFBQWEsR0FBR3BDLFNBQWlCO0lBQ25ELE1BQU0sQ0FBQ3FDLFdBQVdDLGFBQWEsR0FBR3RDLFNBQWlCO0lBRW5ELE1BQU0sQ0FBQ3VDLFFBQVFDLFVBQVUsR0FBR3hDLFNBQVM7SUFDckMsTUFBTSxDQUFDeUMsVUFBVUMsWUFBWSxHQUFHMUMsU0FBaUI7SUFDakQsTUFBTSxDQUFDMkMsY0FBY0MsZ0JBQWdCLEdBQUc1QyxTQUFpQjtJQUN6RCxNQUFNLENBQUM2QyxxQkFBcUJDLHVCQUF1QixHQUFHOUMsU0FBUyxFQUFFO0lBQ2pFLE1BQU0sQ0FBQytDLHVCQUF1QkMseUJBQXlCLEdBQUdoRCxTQUFTO0lBRW5FLE1BQU0sRUFBRWlELG1CQUFtQixFQUFFQyxTQUFTLEVBQUUsR0FBR2hDO0lBRTNDLE1BQU1pQyxZQUFZLElBQUk5QyxXQUFXLEVBQUUsRUFBRTtJQUVyQyx5Q0FBeUM7SUFDekMsTUFBTSxFQUFFK0MsR0FBRyxFQUFFLEdBQUd2QztJQUVoQixNQUFNd0MsT0FBT0QsS0FBS0U7SUFFbEIsTUFBTUMsY0FBYyxJQUFJLFNBQVM7SUFFakMsU0FBU0MsWUFBWUMsUUFBMEIsRUFBRUMsT0FBZSxFQUFFQyxDQUFTLEVBQUVDLEtBQWE7UUFDdEYsSUFBSSxDQUFDSCxVQUFVLFFBQVEsMkNBQTJDO1FBRWxFLE1BQU1JLElBQUlKLFFBQVEsQ0FBQyxFQUFFO1FBQ3JCLE1BQU1LLElBQUlMLFFBQVEsQ0FBQyxFQUFFO1FBQ3JCLE1BQU1NLFVBQVVaLFVBQVVhLGNBQWM7UUFDeEMsTUFBTUMsV0FBV0YsT0FBTyxDQUFDQSxRQUFRRyxNQUFNLEdBQUcsRUFBRTtRQUM1QyxNQUFNQyxjQUFjRixZQUFZQSxRQUFRLENBQUMsRUFBRTtRQUMzQyxJQUFJRyxhQUFhVjtRQUNqQixJQUFJUyxnQkFBZ0JFLFdBQVc7WUFDM0IsSUFBSUMsY0FBY0YsYUFBYTVDLElBQUkyQztZQUVuQyxJQUFJekMsS0FBSzZDLEdBQUcsQ0FBQ0QsZUFBZTVDLEtBQUtDLEVBQUUsRUFBRTtnQkFDakMsTUFBTTZDLE9BQU9GLGVBQWUsSUFBSSxJQUFJLENBQUM7Z0JBQ3JDQSxjQUFjLENBQUNFLE9BQVEsQ0FBQSxJQUFJOUMsS0FBS0MsRUFBRSxHQUFHRCxLQUFLNkMsR0FBRyxDQUFDRCxZQUFXO1lBQzdEO1lBQ0FGLGFBQWFELGNBQWNHO1FBQy9CO1FBQ0FuQixVQUFVc0IsZ0JBQWdCLENBQUM7WUFBQ1o7WUFBR0M7WUFBR007WUFBWVQ7U0FBRTtRQUVoRFIsVUFBVXVCLGNBQWMsQ0FBQ3ZCLFVBQVVhLGNBQWMsR0FBR1csS0FBSyxDQUFDLENBQUM7SUFDL0Q7SUFFQSw2RUFBNkU7SUFDN0UsYUFBYTtJQUNiLFNBQVNDLHFCQUFxQm5CLFFBQTBCLEVBQUVvQixRQUFnQixFQUFFQyxVQUFrQjtRQUMxRixNQUFNQyxPQUFPM0IsS0FBSzRCO1FBQ2xCLElBQUksQ0FBQ0QsTUFBTSxPQUFPdEIsVUFBVSw0Q0FBNEM7UUFFeEUsTUFBTXdCLFNBQVNGLElBQUksQ0FBQyxFQUFFO1FBRXRCLE9BQU87WUFDSHRCLFFBQVEsQ0FBQyxFQUFFLEdBQUcsQUFBQy9CLEtBQUt3RCxHQUFHLENBQUNMLFlBQVlJLFNBQVNILGFBQWEsSUFBSztZQUMvRHJCLFFBQVEsQ0FBQyxFQUFFLEdBQUcsQUFBQy9CLEtBQUt5RCxHQUFHLENBQUNOLFlBQVlJLFNBQVNILGFBQWEsSUFBSztTQUNsRTtJQUNMO0lBRUEsU0FBU007UUFDTCxJQUFJLENBQUMvQixNQUFNO1FBRVgsd0NBQXdDO1FBQ3hDLElBQUlNLElBQUkwQixLQUFLQyxHQUFHLEtBQUtuRCxZQUFZO1FBQ2pDd0IsSUFBSWpDLEtBQUs2RCxHQUFHLENBQUM1QixHQUFHdEI7UUFDaEJDLGFBQWFxQjtRQUViLE1BQU02QixJQUFJckMsVUFBVXNDLGdCQUFnQixDQUFDOUIsR0FBRztRQUV4QyxJQUFJNkIsR0FBRztZQUNIbkMsS0FBS3FDLFNBQVMsQ0FBQ2QscUJBQXFCO2dCQUFDWSxDQUFDLENBQUMsRUFBRTtnQkFBRUEsQ0FBQyxDQUFDLEVBQUU7YUFBQyxFQUFFLENBQUNBLENBQUMsQ0FBQyxFQUFFLEVBQUVuQyxLQUFLc0MsYUFBYSxNQUFNO1lBQ2pGdEMsS0FBS3VDLFdBQVcsQ0FBQyxDQUFDSixDQUFDLENBQUMsRUFBRTtZQUN0QnhELE9BQU93RDtZQUVQLE1BQU1LLGVBQWU3RSxLQUFLOEUsS0FBSyxDQUFDM0YsU0FBUztnQkFBQ3FGLENBQUMsQ0FBQyxFQUFFO2dCQUFFQSxDQUFDLENBQUMsRUFBRTthQUFDO1lBQ3JEcEUsYUFBYTJFLE9BQU8sQ0FBQ0MsQ0FBQUE7Z0JBQ2pCLG9EQUFvRDtnQkFDcEQsTUFBTUMsZUFBZWpGLEtBQUs4RSxLQUFLLENBQUNFLEtBQUtFLFlBQVk7Z0JBQ2pELE1BQU1DLFdBQVduRixLQUFLbUYsUUFBUSxDQUFDTixjQUFjSSxjQUFjO29CQUFFRyxPQUFPO2dCQUFTO2dCQUM3RSxJQUFJRCxXQUFXNUMsZUFBZSxDQUFDaEIsUUFBUTtvQkFDbkNDLFVBQVU7b0JBQ1Y2RCxRQUFRQyxLQUFLLENBQUM7b0JBQ2Q1RCxZQUFZc0QsS0FBS08sSUFBSTtvQkFDckJ6RCx1QkFBdUJtRDtnQkFDM0I7WUFDSjtZQUVBLE1BQU1PLHNCQUFzQnhGLEtBQUttRixRQUFRLENBQUN0RCxxQkFBcUJnRCxjQUFjO2dCQUFFTyxPQUFPO1lBQVM7WUFFL0YsSUFBSUksc0JBQXNCakQsYUFBYTtnQkFDbkNYLGdCQUFnQjREO2dCQUVoQixJQUFJdkQscUJBQXFCO29CQUNyQm9ELFFBQVFJLEdBQUcsQ0FBQyxpQ0FBaUNELHFCQUFxQkEscUJBQXFCO29CQUN2RnZELG9CQUFvQnlELG1CQUFtQixDQUFDRixxQkFBcUJBLHFCQUFxQjtnQkFDdEY7Z0JBRUEsY0FBYztnQkFDZCxJQUFJQSxzQkFBc0IsR0FBRztvQkFDekJILFFBQVFJLEdBQUcsQ0FBQyxxQkFBcUJoRTtvQkFDakNPLHlCQUF5QjtnQkFDN0IsT0FBTztvQkFDSEEseUJBQXlCO2dCQUM3QjtZQUNKO1lBQ0Esb0RBQW9EO1lBQ3BELElBQUl3RCxzQkFBc0JqRCxlQUFlaEIsUUFBUTtnQkFDN0NDLFVBQVU7Z0JBQ1ZVO1lBQ0o7UUFDSjtJQUNKO0lBR0EsU0FBU3lELGtCQUFrQlQsWUFBOEIsRUFBRUssSUFBWSxFQUFFSyxHQUFXO1FBQ2hGLGtEQUFrRDtRQUNsRCxNQUFNQyxnQkFBZ0IsSUFBSXpHLE1BQU1GLFdBQVdnRztRQUMzQyxxQkFDSSxRQUFDeEY7WUFBU29HLFVBQVVEOzs4QkFDaEIsUUFBQ2pHLE9BQU9BLE1BQU07OEJBRVYsY0FBQSxRQUFDQSxPQUFPbUcsS0FBSzt3QkFBQ0MsS0FBSzNGO3dCQUFRNEYsUUFBUTs0QkFBQzs0QkFBSzt5QkFBSTs7Ozs7Ozs7Ozs7OEJBRWpELFFBQUNuRztvQkFBT29HLFNBQVM7b0JBQVNDLFdBQVU7OEJBQy9CWjs7Ozs7OztXQU4rQks7Ozs7O0lBVWhEO0lBRUEsU0FBU1EseUJBQXlCbEIsWUFBOEIsRUFBRUssSUFBWSxFQUFFSyxHQUFXO1FBQ3ZGLE1BQU1TLGlCQUFpQixJQUFJL0csT0FBT0osV0FBV2dHLGVBQWUzQztRQUM1RCxxQkFDSSxRQUFDN0M7WUFBU29HLFVBQVVPO3NCQUNoQixjQUFBLFFBQUN6RyxPQUFPQSxNQUFNOztrQ0FDVixRQUFDQSxPQUFPMEcsS0FBSzt3QkFBQ0MsT0FBTzs7Ozs7O2tDQUNyQixRQUFDM0csT0FBTzRHLE9BQU87d0JBQUNELE9BQU87d0JBQVNFLE9BQU87Ozs7Ozs7Ozs7OztXQUhOYjs7Ozs7SUFPakQ7SUFFQSxxQkFFSSxRQUFDYzs7MEJBQ0csUUFBQy9HO2dCQUNHZ0gsVUFBVTtnQkFDVkMsaUJBQWlCO29CQUFFQyxvQkFBb0I7Z0JBQUs7Z0JBRTVDQyxVQUFVN0gsWUFDTixDQUFDOEg7b0JBQ0csTUFBTUMsU0FBU0QsRUFBRUUsTUFBTTtvQkFDdkIsTUFBTXhFLFdBQVd1RSxPQUFPRSxXQUFXO29CQUNuQyxJQUFJekUsVUFBVTt3QkFDVixNQUFNLENBQUNJLEdBQUdDLEVBQUUsR0FBR0wsVUFBVSxvREFBb0Q7d0JBQzdFdkIsWUFBWSxJQUFJN0IsV0FBVzs0QkFBQ29EO3lCQUFTO3dCQUNyQyxNQUFNRSxJQUFJMEIsS0FBS0MsR0FBRzt3QkFDbEIsNkNBQTZDO3dCQUM3QzlCLFlBQVk7NEJBQUNLOzRCQUFHQzt5QkFBRSxFQUFFa0UsT0FBT0csVUFBVSxNQUFNLEdBQUd4RSxHQUFHcUUsT0FBT0ksUUFBUSxNQUFNLElBQUksOEJBQThCO3dCQUV4RyxNQUFNQyxTQUFTbEYsVUFBVWEsY0FBYzt3QkFDdkMsTUFBTXNFLE1BQU1ELE9BQU9uRSxNQUFNO3dCQUN6QixJQUFJb0UsT0FBTyxHQUFHOzRCQUNWbEcsYUFBYSxBQUFDaUcsQ0FBQUEsTUFBTSxDQUFDQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEdBQUdELE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBRSxBQUFELElBQU1DLENBQUFBLE1BQU0sQ0FBQTt3QkFDOUQ7d0JBRUFsRDtvQkFFSjtnQkFDSixHQUNBO29CQUFDakM7b0JBQVdDO2lCQUFJLENBQUMsMkJBQTJCOzs7Ozs7OzBCQUlwRCxRQUFDM0M7Z0JBQWE4SCxRQUFROztrQ0FDbEIsUUFBQzNILE9BQU9BLE1BQU07OzBDQUNWLFFBQUNBLE9BQU9tRyxLQUFLO2dDQUFDQyxLQUFLMUY7Z0NBQWMyRixRQUFRO29DQUFDO29DQUFLO2lDQUFJOzs7Ozs7MENBQ25ELFFBQUNyRyxPQUFPNEcsT0FBTztnQ0FBQ0QsT0FBTztnQ0FBV0UsT0FBTzs7Ozs7Ozs7Ozs7O29CQUU1QzFGLHFCQUFPLFFBQUNyQjt3QkFBU29HLFVBQVUsSUFBSTFHLE1BQU0yQjs7Ozs7O29CQUNyQ0UsMEJBQVksUUFBQ3ZCO3dCQUFTb0csVUFBVTdFOzs7Ozs7Ozs7Ozs7MEJBR3JDLFFBQUN4QjtnQkFBYThILFFBQVE7MEJBQ2pCbkgsYUFBYWdDLEdBQUcsQ0FBQyxDQUFDNEMsTUFBTXdDLElBQU03QixrQkFBa0JYLEtBQUtFLFlBQVksRUFBRUYsS0FBS08sSUFBSSxFQUFFaUM7Ozs7OzswQkFHbkYsUUFBQy9IO2dCQUFhOEgsUUFBUTswQkFDakJuSCxhQUFhZ0MsR0FBRyxDQUFDLENBQUM0QyxNQUFNd0MsSUFBTXBCLHlCQUF5QnBCLEtBQUtFLFlBQVksRUFBRUYsS0FBS08sSUFBSSxFQUFFaUM7Ozs7OzswQkFFMUYsUUFBQ2pIO2dCQUFja0gsd0JBQVUsUUFBQ2Y7OEJBQUk7Ozs7OzswQkFDekJuRix3QkFBVSxRQUFDdEI7b0JBQVVzQixRQUFRQTtvQkFBUUMsV0FBV0E7b0JBQVdDLFVBQVVBO29CQUFVRSxjQUFjQTtvQkFBYytGLGlCQUFpQjNGOzs7Ozs7Ozs7Ozs7Ozs7OztBQU03STtHQXZNU2pCOztRQWFzQ1o7UUFLM0JMOzs7S0FsQlhpQjtBQTBNVCxlQUFlLFNBQVM2Rzs7SUFDcEIsTUFBTSxDQUFDQyxZQUFZQyxjQUFjLEdBQUc3SSxTQUFTO0lBRTdDLHFCQUNJO2tCQUVJLGNBQUEsUUFBQ087WUFDRzRHLFdBQVU7WUFDVjJCLFNBQVM7Z0JBQUVDLFFBQVE3SSxXQUFXO29CQUFDO29CQUFHO2lCQUFFO2dCQUFHOEksTUFBTTtZQUFHOzs4QkFFaEQsUUFBQ2pJLFNBQVNrSSxPQUFPO29CQUFDOUIsV0FBVTs4QkFDeEIsY0FBQSxRQUFDK0I7d0JBQU9DLFNBQVMsSUFBTU4sY0FBYztrQ0FBTzs7Ozs7Ozs7Ozs7Z0JBSS9DRCw0QkFBYyxRQUFDekg7b0JBQVNvQixRQUFRcUc7b0JBQVlwRyxXQUFXcUc7Ozs7Ozs4QkFDeEQsUUFBQ3JJOzs7Ozs4QkFDRCxRQUFDc0I7Ozs7Ozs7Ozs7OztBQU1qQjtJQXZCd0I2RztNQUFBQSJ9